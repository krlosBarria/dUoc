package teatrook;


public class Proceso {
    Cliente espacios[][]= new Cliente[3][10];
    
    //Creacion de clase Cliente para almacenar los datos del arreglo
    public Proceso(){
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 10; j++) {
                espacios[i][j] = new Cliente();
            }
        }
    }
    
    //Metodo de compra de entradas
    public void Vender(){
        String nombre;
        boolean filaOk = false;
        boolean asientoOk = false;
        int edad;
        int fila, asiento, valorGral = 35000;
        
        System.out.println("Ingrese su nombre: ");TeatroOK.teclado.nextLine();
        nombre = TeatroOK.teclado.nextLine();
        System.out.println("Ingrese su Edad: ");
        edad = TeatroOK.teclado.nextInt();
        
        // Ciclo Validación de selección de filas
        do {
            System.out.println("Seleccione la Fila  [1..3] :");
            fila = TeatroOK.teclado.nextInt();

            //Verificación valor de Fila
            if (fila >= 1 && fila <= 3) {
                filaOk = true;
                
                // Ciclo Validación de selección de Asiento
                do {                    
                    System.out.println("Seleccione el asiento [1..10] :");
                    asiento = TeatroOK.teclado.nextInt();
                    
                    //Verificación valor de Asiento
                    if (asiento >= 1 && asiento <= 10) {
                        asientoOk = true;
                        
                        //Verificacion de disponibilidad de ubicacion disponible
                        if (espacios[fila-1][asiento-1].estadoCliente == Estados.Disponible) {
                            espacios[fila-1][asiento-1].nomCliente = nombre;
                            espacios[fila-1][asiento-1].edadCliente = edad;
                            if (edad <=18) {
                                espacios[fila-1][asiento-1].pagoCliente = valorGral - (valorGral * 0.10);
                                System.out.println("Descuento Estudiante 10% $"+(valorGral * 0.10));
                                System.out.println("Ticket Fila: "+fila+" Asiento: "+asiento);
                                System.out.println("Total a Pagar: $"+espacios[fila-1][asiento-1].pagoCliente);
                            }else{
                                if (edad >=60) {
                                    espacios[fila-1][asiento-1].pagoCliente = valorGral - (valorGral * 0.15);
                                    System.out.println("Descuento 3era Edad 15% $"+(valorGral * 0.15));
                                    System.out.println("Ticket Fila: "+fila+" Asiento: "+asiento);
                                    System.out.println("Total a Pagar: $"+espacios[fila-1][asiento-1].pagoCliente);
                                } else {
                                    espacios[fila-1][asiento-1].pagoCliente = valorGral;
                                    //System.out.println("Valor sin descuento $"+espacios[fila-1][asiento-1].pagoCliente);
                                    System.out.println("Ticket Fila: "+fila+" Asiento: "+asiento);
                                    System.out.println("Total a Pagar: $"+espacios[fila-1][asiento-1].pagoCliente);
                                }
                            }
                            espacios[fila-1][asiento-1].estadoCliente = Estados.Ocupado;
                            System.out.println("El Ticket de asiento esta reservado\n");
                        } else {
                            System.out.println("El Asiento no esta disponible");
                        }
                    }else{
                        System.out.println("Asiento ingresado no valido.");
                        System.out.println("Favor ingresar numero Asiento [1 a 10].");
                    }
                } while (asientoOk != true);
            }else{
                System.out.println("Valor de Fila ingresado no valido.");
                System.out.println("Favor ingresar nuevamente Fila [1 a 3].");
            }
        } while (filaOk != true);
    }
    
    //Metodo mostrar los asientos del Teatro
    public void showAsientos(){
        
        System.out.println("Distribucion Asientos");
        System.out.println(" 1  2  3  4  5  6  7  8  9  10 |");
        for (int i = 0; i < 3; i++) {
            System.out.println("Fila "+(i+1));
            for (int j = 0; j < 10; j++) {
//                System.out.print(" | "+(j+1));
                if (espacios[i][j].estadoCliente == Estados.Disponible){
                    System.out.print(" _ ");
                } else {
                    System.out.print(" X ");
                }
             }
            System.out.println(" |");
            System.out.println("\n");
        }
    }
    
    //conteo de Estado de Ventas
    public void EstadoVentas(){
        
        for (int i = 0; i < 3; i++) {
            System.out.println("Fila "+(i+1));
            for (int j = 0; j < 10; j++) {
                if (espacios[i][j].estadoCliente == Estados.Disponible){
                    System.out.print(" _ ");
                } else {
                    System.out.print(" X ");
                    TeatroOK.totalEntradas++;
                    TeatroOK.totalVendido = TeatroOK.totalVendido + espacios[i][j].pagoCliente;
                }
             }
            System.out.println(" |");
            System.out.println("\n");
        }
        System.out.println("Cantidad de Entradas vendidas: "+TeatroOK.totalEntradas);
        System.out.println("Por un total de $"+TeatroOK.totalVendido);
        System.out.println("\n");
    }
    

    //Limpiaar los datos del sistema
    public void limpiarDatos(){
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 10; j++) {
                espacios[i][j].estadoCliente = Estados.Disponible;
             }
        }
        TeatroOK.teclado.close();
    }
}
