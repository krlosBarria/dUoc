package com.duoc.adminbiblio.entidades;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 10 junio 2024 
 * @asignatura:  
 *
 */
public class Biblioteca {

}
