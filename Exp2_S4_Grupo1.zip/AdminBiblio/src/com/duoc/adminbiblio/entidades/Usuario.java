package com.duoc.adminbiblio.entidades;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 10 junio 2024
 * @asignatura: DESARROLLO ORIENTADO A OBJETOS I
 * @Grupo: Exp2_S4_Grupo1
 *
 */
public class Usuario {
    private String rutSocio, nomSocio, apeSocio, direccionSoc, ciudadSoc;
    private int telefonoSoc, edadSoc;

    //Constructor
    public Usuario(String rutSocio, String nomSocio, String apeSocio, String direccionSoc, String ciudadSoc, int telefonoSoc, int edadSoc) {
        this.rutSocio = rutSocio;
        this.nomSocio = nomSocio;
        this.apeSocio = apeSocio;
        this.direccionSoc = direccionSoc;
        this.ciudadSoc = ciudadSoc;
        this.telefonoSoc = telefonoSoc;
        this.edadSoc = edadSoc;
    }
    
    //Getters/Setters
    public String getRutSocio() {
        return rutSocio;
    }

    public void setRutSocio(String rutSocio) {
        this.rutSocio = rutSocio;
    }

    public String getNomSocio() {
        return nomSocio;
    }

    public void setNomSocio(String nomSocio) {
        this.nomSocio = nomSocio;
    }

    public String getApeSocio() {
        return apeSocio;
    }

    public void setApeSocio(String apeSocio) {
        this.apeSocio = apeSocio;
    }

    public String getDireccionSoc() {
        return direccionSoc;
    }

    public void setDireccionSoc(String direccionSoc) {
        this.direccionSoc = direccionSoc;
    }

    public String getCiudadSoc() {
        return ciudadSoc;
    }

    public void setCiudadSoc(String ciudadSoc) {
        this.ciudadSoc = ciudadSoc;
    }

    public int getTelefonoSoc() {
        return telefonoSoc;
    }

    public void setTelefonoSoc(int telefonoSoc) {
        this.telefonoSoc = telefonoSoc;
    }

    public int getEdadSoc() {
        return edadSoc;
    }

    public void setEdadSoc(int edadSoc) {
        this.edadSoc = edadSoc;
    }

    @Override
    public String toString() {
        return "Usuario{" + "rutSocio=" + rutSocio + ", nomSocio=" + nomSocio + ", apeSocio=" + apeSocio + ", direccionSoc=" + direccionSoc + ", ciudadSoc=" + ciudadSoc + ", telefonoSoc=" + telefonoSoc + ", edadSoc=" + edadSoc + '}';
    }
}
