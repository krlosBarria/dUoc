package com.duoc.adminbiblio.excepciones;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 10 junio 2024
 * @asignatura: DESARROLLO ORIENTADO A OBJETOS I
 * @Grupo: Exp2_S4_Grupo1
 *
 */
public class LibroYaPrestadoException extends Exception{

    public LibroYaPrestadoException(String message) {
        super(message);
    }

    public LibroYaPrestadoException() {
    }
}
