package com.duoc.adminbiblio.principal;

import com.duoc.adminbiblio.entidades.Libro;
import com.duoc.adminbiblio.entidades.Usuario;
import com.duoc.adminbiblio.excepciones.LibroNoEncontradoException;
import com.duoc.adminbiblio.excepciones.LibroYaPrestadoException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 10 junio 2024
 * @asignatura: DESARROLLO ORIENTADO A OBJETOS I
 * @Grupo: Exp2_S4_Grupo1
 *
 */
public class Main {

    private static Scanner teclado = new Scanner(System.in);
    private static int opcion, telefonoSoc, edadSoc;
    private static String rutSoc, nombreSoc, apellidosSoc, direccionSoc, ciudadSoc;
    private static String tituloLibro, autorLibro;
    private static boolean estadoLibro;
    private static ArrayList<Libro> libros = new ArrayList<>();
    private static ArrayList<Usuario> socios = new ArrayList<>();

    public static void main(String[] args) {

        do {
            menuPri();

            try {
                opcion = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Servidor detecta ingreso no valido");
                opcion = 0;
                teclado.next();  //limpiar buffer

            } catch (ArithmeticException ex) {
                System.out.println("Falla division por Cero");
            }
            switch (opcion) {
                case 1 ->
                    crearRegistro();
                case 2 ->
                    buscarLibro();
                case 3 ->
                    prestarLibro();
                case 4 ->
                    crearUsuario();
                case 5 ->
                    System.out.println("Goodbye");
                default ->
                    System.out.println("Opcion fuera de rango");
            }
        } while (opcion != 5);
        teclado.close();
        libros.clear();
    }

    //Método Menú Principal
    static void menuPri() {
        String s;
        s = """
        ----- Biblioteca Rotaria Valpo -----
            1.- Crear Registro de Libro.
            2.- Buscar Libro.
            3.- Prestamo de Libro.
            4.- Crear Socio (Usuario)
            5.- Salir.
        Seleccione su opcion:""";
        System.out.println(s);
    }

    //Método Crear Registro de Libros ==> Opcion 01
    static void crearRegistro() {
        int estado = 0;
        char guardar = 0;
        boolean seguimos;

        System.out.println("--- Ingrese los datos del Libro ---");
        System.out.print("Titulo: ");
        teclado.nextLine();
        tituloLibro = teclado.nextLine();
        System.out.print("Autor: ");
        autorLibro = teclado.nextLine();

        do {
            System.out.print("Estado (1=disponible|2=prestado): ");
            try {
                estado = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Opcion no valida");
                teclado.next();
                estado = 0;
            }
            if (estado == 1) {
                estadoLibro = true;
            } else {
                if (estado == 2) {
                    estadoLibro = false;
                } else {
                    System.out.println("elija una opcion valida");
                    estado = 0;
                }
            }
        } while (estado == 0);

        do {
            //Guardar registro Libro
            System.out.print("Desea crear el registro del Libro? (Si/No): ");
            try {
                guardar = teclado.next().toUpperCase().charAt(0); //Convierte la entrada en Mayúscula

            } catch (InputMismatchException ex) {
                System.out.println("debe ingresar solo la letra de la opcion: " + ex.getMessage());
                teclado.nextLine();
            }

            //Verfica si la entrada es 'S' o 'N'
            if (guardar == 'S') {
                System.out.println("Registro Almacenado.");
                libros.add(new Libro(tituloLibro, autorLibro, estadoLibro));
                System.out.println(libros.toString());
                seguimos = true;
            } else {
                if (guardar == 'N') {
                    System.out.println("Sin registrar.");
                    seguimos = true;
                } else {
                    System.out.println("Por Favor, ingrese 'S' o 'N'.");
                    seguimos = false;
                }
            }
        } while (seguimos != true);
        System.out.println("\n=======================================");
    }

    //Método Buscar libro ==> Opcion 02
    static void buscarLibro() {

        if (libros.isEmpty()) {
            try {
                //lanza Exception Personalizada
                throw new LibroNoEncontradoException();
            } catch (LibroNoEncontradoException ex) {
                System.out.println("No existen Libros - Excepcion Personalizada\n" + ex.toString());
            }
        } else {
            mostrarLibros();
            System.out.print("Ingrese nombre del libro a buscar: ");
            System.out.println("\n=======================================");
        }
    }

    //Método Prestar Libro ==> Opcion 03
    static void prestarLibro() {
        if (libros.isEmpty()) {
            try {
                //lanza Exception Personalizada
                throw new LibroYaPrestadoException();
            } catch (LibroYaPrestadoException ex) {
                System.out.println("No existen Libros para Prestar - Excepcion Personalizada\n" + ex.toString());
            }
        } else {
            System.out.println("--- Prestamo de Libros ---");
            System.out.println("\n=======================================");
            mostrarLibros();
        }
    }

    //Método Crear Socio Usuario ==> Opcion 04
    static void crearUsuario() {
        char guardamos = 0;
        boolean seguimos = false;

        System.out.println("--- Crear Registro de Socios---");
        System.out.print("Rut: "); teclado.nextLine();
        rutSoc = teclado.nextLine();

        System.out.print("Nombre: ");
        nombreSoc = teclado.nextLine();

        System.out.print("Apellidos: ");
        apellidosSoc = teclado.nextLine();

        System.out.print("Direccion: ");
        direccionSoc = teclado.nextLine();

        System.out.print("Ciudad: ");
        ciudadSoc = teclado.nextLine();
        do {
            System.out.print("Telefono: ");
            try {
                telefonoSoc = teclado.nextInt();
                seguimos = true;
            } catch (InputMismatchException ex) {
                System.out.println("Ingrese un valor valido para su telefono ==>" + ex.toString() + " = " + ex.getMessage());
                telefonoSoc = 0;
                teclado.nextInt();
                seguimos = false;
            }
        } while (seguimos != true);

        do {    //Validacion de ingreso Edad - debe ser mayor a 13 años
            System.out.print("Edad: ");
            try {
                edadSoc = teclado.nextInt();
                if (edadSoc > 14 && edadSoc < 120) {
                    seguimos = true;
                } else {
                    System.out.println("""
                                       Edad debe ser superior a 13 annios;
                                       Pero tampoco la edad de un ser importal.""");
                    seguimos = false;
                }
            } catch (InputMismatchException ex) {
                System.out.println("favor ingrese un valor valido para su edad desde 14 a 120 anio(s)");
                edadSoc = 0;
                teclado.nextInt();
                seguimos = false;
            }
        } while (seguimos != true);

        do {
            //Guardar registro del Socio
            System.out.println("desea crear registro? Si/No: ");
            try {
                guardamos = teclado.next().toUpperCase().charAt(0); //Convierte la entrada en Mayúscula

            } catch (InputMismatchException ex) {
                System.out.println("Esperamos solo una letra y nada mas");
                teclado.next();
                // seguimos = false;
            }

            //Verfica si la entrada es 'S' o 'N'
            if (guardamos == 'S') {
                System.out.println("Registro Socio Creado");
                socios.add(new Usuario(rutSoc, nombreSoc, apellidosSoc,
                        direccionSoc, ciudadSoc, telefonoSoc, edadSoc));
                System.out.println(socios.toString());
                seguimos = true;
            } else {
                if (guardamos == 'N') {
                    System.out.println("Sin registrar.");
                    seguimos = true;
                } else {
                    System.out.println("Por Favor, ingrese 'S' o 'N'.");
                    seguimos = false;
                }
            }
        } while (seguimos != true);
        System.out.println("\n=======================================");
    }

    static void mostrarLibros() {
        if (libros.isEmpty()) {
            System.out.println("No existen libros");
        } else {
            for (Libro librox : libros) {
                System.out.println("Titulo.: " + librox.getTitulo() + " Autor.: " + librox.getAutor() + " Disponible.: " + (librox.isEstado() ? "SI" : "NO"));
            }
        }
    }
}
