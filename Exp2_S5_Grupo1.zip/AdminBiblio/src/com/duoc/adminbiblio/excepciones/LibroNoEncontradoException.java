package com.duoc.adminbiblio.excepciones;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 17 junio 2024
 * @asignatura: DESARROLLO ORIENTADO A OBJETOS I
 * @Grupo: Exp2_S5_Grupo1
 *
 */
public class LibroNoEncontradoException extends Exception {

    public LibroNoEncontradoException(String message) {
        super("Libro no Existe o fue eliminado.");
    }

    public LibroNoEncontradoException() {
    }
    
}
