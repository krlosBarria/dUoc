
package teatromoros8;

//
public enum Estados {
    Disponible,
    Ocupado
}
