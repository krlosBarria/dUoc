package teatromoros8;


public class Proceso {
    Cliente espacios[][]= new Cliente[3][10];
    int valorGral = 35000;
    boolean tieneVentas;
    
    //Creacion de clase Cliente para almacenar los datos del arreglo
    public Proceso(){
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 10; j++) {
                espacios[i][j] = new Cliente();
            }
        }
    }
    
    //01 Metodo de compra de Tickets
    public void Vender(){
        int idVenta;
        String nombre;
        String tipoUbi ="";
        boolean filaOk = false;
        boolean asientoOk = false;
        int edad;
        int fila, asiento;
        
        System.out.println("Ingrese su nombre: ");TeatroOK.teclado.nextLine();
        nombre = TeatroOK.teclado.nextLine();
        System.out.println("Ingrese su Edad: ");
        edad = TeatroOK.teclado.nextInt();
        
        // Ciclo Validación de selección de filas
        do {
            System.out.println("Seleccione la Ubicacion  ");
            System.out.println("[1=Vip, 2=Platea, 3=Balcon] :");
            fila = TeatroOK.teclado.nextInt();

            //Verificación valor de Fila
            if (fila >= 1 && fila <= 3) {
                filaOk = true;
                
                // Ciclo Validación de selección de Asiento
                do {
                    System.out.println("Seleccione el asiento [1..10] :");
                    asiento = TeatroOK.teclado.nextInt();
                    switch (fila) {
                        case 1 -> {
                            tipoUbi="VIP";
                        }
                        case 2 -> {
                            tipoUbi="Platea";
                        }
                        case 3 -> {
                            tipoUbi="Balcon";
                            
                        }
                    }
                    
                    //Verificación valor de Asiento
                    if (asiento >= 1 && asiento <= 10) {
                        asientoOk = true;
                        
                        //Verificacion de disponibilidad de ubicacion disponible
                        if (espacios[fila-1][asiento-1].estadoCliente == Estados.Disponible) {
                            espacios[fila-1][asiento-1].nomCliente = nombre;
                            espacios[fila-1][asiento-1].edadCliente = edad;
                            espacios[fila-1][asiento-1].entradaCliente = tipoUbi;
                            System.out.println("=====================================");
                            System.out.println("    Datos de tu compra");
                            System.out.println("=====================================");
                            if (edad <=18) {
                                espacios[fila-1][asiento-1].pagoCliente = valorGral - (valorGral * 0.10);
                                espacios[fila-1][asiento-1].descCliente = (0.10);
                                espacios[fila-1][asiento-1].asientoCliente = asiento;
                                System.out.println("Descuento Estudiante 10% $"+(valorGral * 0.10));
                                System.out.println("Ticket: "+tipoUbi+" Asiento: "+asiento);
                                System.out.println("Total a Pagar: $"+espacios[fila-1][asiento-1].pagoCliente);
                            }else{
                                if (edad >=60) {
                                    espacios[fila-1][asiento-1].pagoCliente = valorGral - (valorGral * 0.15);
                                    espacios[fila-1][asiento-1].descCliente = (0.15);
                                    espacios[fila-1][asiento-1].asientoCliente = asiento;
                                    System.out.println("Descuento 3era Edad 15% $"+(valorGral * 0.15));
                                    System.out.println("Ticket: "+tipoUbi+" Asiento: "+asiento);
                                    System.out.println("Total a Pagar: $"+espacios[fila-1][asiento-1].pagoCliente);
                                } else {
                                    espacios[fila-1][asiento-1].pagoCliente = valorGral;
                                    espacios[fila-1][asiento-1].descCliente = 0;
                                    espacios[fila-1][asiento-1].asientoCliente = asiento;
                                    System.out.println("Ticket: "+tipoUbi+" Asiento: "+asiento);
                                    System.out.println("Total a Pagar: $"+espacios[fila-1][asiento-1].pagoCliente);
                                }
                            }
                            espacios[fila-1][asiento-1].estadoCliente = Estados.Ocupado;
                            idVenta = (int) (Math.random()*100);    //Genrea ID de venta de forma aleatoria
                            espacios[fila-1][asiento-1].idVenta = idVenta;
                            System.out.println("Codigo de Ticket: "+idVenta);
                            System.out.println("El Ticket de asiento esta reservado\n");
                        } else {
                            System.out.println("El Asiento no esta disponible");
                        }
                    }else{
                        System.out.println("Asiento ingresado no valido.");
                        System.out.println("Favor ingresar numero Asiento [1 a 10].");
                    }
                } while (asientoOk != true);
            }else{
                System.out.println("Valor ingresado no valido.");
                System.out.println("Favor ingresar nuevamente Fila [1 a 3].");
            }
        } while (filaOk != true);
    }
    
    //Método mostrar los asientos del Teatro
    public void showAsientos(){
        String tipoFila;
        
        System.out.println("--- Distribucion de Asientos ---");
        System.out.println(" 1  2  3  4  5  6  7  8  9  10 |");
        for (int i = 0; i < 3; i++) {
            switch (i) {
                case 0 -> tipoFila = "VIP";
                case 1 -> tipoFila = "Platea";
                case 2 -> tipoFila = "Balcon";
                default -> throw new AssertionError();
            }
            System.out.println((i+1)+" "+tipoFila);
            for (int j = 0; j < 10; j++) {
                if (espacios[i][j].estadoCliente == Estados.Disponible){
                    System.out.print(" _ ");
                } else {
                    System.out.print(" X ");
                }
             }
            System.out.println(" |");
            System.out.println("\n");
        }
    }
    
    //02 Resumen de Ventas [Ubicacion, Costo Final y descuentos
    public void resumenVentas(){
        
        vendimos();
        if (tieneVentas) {
            System.out.println(" Resumen de Ventas");
            System.out.println(" =====================================");
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 10; j++) {
                    if (espacios[i][j].estadoCliente != Estados.Disponible){
                        System.out.println(" Codigo Ticket: "+espacios[i][j].idVenta);
                        System.out.println(" Ubicacion: "+espacios[i][j].entradaCliente);
                        System.out.println(" Numero de asiento: "+espacios[i][j].asientoCliente);
                        System.out.println(" Nombre: "+espacios[i][j].nomCliente);
                        System.out.println(" Edad: "+espacios[i][j].edadCliente);
                        System.out.println(" Descuento: "+espacios[i][j].descCliente+"%");
                        System.out.println(" Costo Final: $"+espacios[i][j].pagoCliente);
                        System.out.println(" -------------------------------------");
                    }
                }
            }
        }else{
            System.out.println("Sin ventas aun, apurate en asistir. Saludos.");
        }
        System.out.println();
    }
    
    //Método que verifica si hay elementos en el arreglo espacios[][]
    public void vendimos(){
        for (int ii = 0; ii < 3; ii++) {
            for (int j = 0; j < 10; j++) {
                if (espacios[ii][j].estadoCliente != Estados.Disponible){
                    tieneVentas = true;
                }
            }
        }
    }
    
    //03 Generar Boleta
    public void GenerarBoleta(){
        
        vendimos();
        if (tieneVentas) {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 10; j++) {
                    if (espacios[i][j].estadoCliente != Estados.Disponible){
                        System.out.println("*************************************");
                        System.out.println("------ Boleta Teatro Moro -----------");
                        System.out.println("Código Ticket: "+espacios[i][j].idVenta);
                        System.out.println("Ubicacion: "+espacios[i][j].entradaCliente);
                        System.out.println("Numero de asiento: "+espacios[i][j].asientoCliente);
                        System.out.println("Costo Base: $"+valorGral);
                        System.out.println("Descuento Aplicado: "+espacios[i][j].descCliente+"%");
                        System.out.println("Costo Final : $"+espacios[i][j].pagoCliente);
                        System.out.println("   --- Gracias por su preferencia ---");
                    }
                }
            }
        }else{
            System.out.println("Sin ventas aun, a comprar se ha dicho");
            System.out.println();
            System.out.println();
        }
    }
    
    //04 Modifica Ticket
    public void modificarTicket(){
        int codigoTicket;
        String nuevoNombre;
        
        vendimos();
        if (tieneVentas) {
            System.out.println("Ingrese numero de ticket: ");
            codigoTicket = TeatroOK.teclado.nextInt();
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 10; j++) {
                    if (espacios[i][j].idVenta == codigoTicket){
                        System.out.println("--------------------------------");
                        System.out.println("--- Datos Ticket a Modificar ---");
                        System.out.println("--------------------------------");
                        System.out.println("Código Ticket: "+espacios[i][j].idVenta);
                        System.out.println("Nombre Asignado: "+espacios[i][j].nomCliente);
                        System.out.print("Ingrese el nuevo Nombre: ");
                        nuevoNombre = TeatroOK.teclado.next();
                        espacios[i][j].nomCliente = nuevoNombre;
                        /*
                        System.out.println("Numero de asiento: "+espacios[i][j].asientoCliente);
                        System.out.println("Costo Base: $"+valorGral);
                        System.out.println("Descuento Aplicado: "+espacios[i][j].descCliente+"%");
                        System.out.println("Costo Final : $"+espacios[i][j].pagoCliente);
                        */
                        System.out.println("Modificacion de nombre realizada");
                        System.out.println("\n");
                    }
                }
            }
        }else{
            System.out.println("No existen Ventas, sin tickets:");
        }
    }

    //05 Eliminar Compra
    public void eliminaTicket(){
        int codigoTicket;
        
        vendimos();
        if (tieneVentas) {
            System.out.println("Ingrese numero de ticket: ");
            codigoTicket = TeatroOK.teclado.nextInt();
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 10; j++) {
                    if (espacios[i][j].idVenta == codigoTicket){
                        System.out.println("------ Datos Ticket a Eliminar-----------");
                        System.out.println("Código Ticket: "+espacios[i][j].idVenta);
                        System.out.println("Nombre Asignado: "+espacios[i][j].nomCliente);
                        System.out.println("Numero de asiento: "+espacios[i][j].asientoCliente);
                        System.out.println("Costo Base: $"+valorGral);
                        System.out.println("Descuento Aplicado: "+espacios[i][j].descCliente+"%");
                        System.out.println("Costo Final : $"+espacios[i][j].pagoCliente);
                        System.out.println("Ticket Eliminado, asiento disponible");
                        espacios[i][j].estadoCliente = Estados.Disponible;
                    }
                }
            }
        }else{
            System.out.println("No existen Ticket, intente nuevamente:");
        }
    }
    
    
    //06 Calcular Ingresos Totales de Ventas
    public void EstadoVentas(){
        String tipoFila;
        
        for (int i = 0; i < 3; i++) {
            switch (i) {
                case 0 -> tipoFila = "VIP";
                case 1 -> tipoFila = "Platea";
                case 2 -> tipoFila = "Balcon";
                default -> throw new AssertionError();
            }
            
            System.out.println((i+1)+" "+tipoFila);
            for (int j = 0; j < 10; j++) {
                if (espacios[i][j].estadoCliente == Estados.Disponible){
                    System.out.print(" _ ");
                } else {
                    System.out.print(" X ");
                    TeatroOK.totalEntradas++;
                    TeatroOK.totalVendido = TeatroOK.totalVendido + espacios[i][j].pagoCliente;
                }
             }
            System.out.println(" |");
            System.out.println("\n");
        }
        System.out.println("Cantidad de Entradas vendidas: "+TeatroOK.totalEntradas);
        System.out.println("Por un total de $"+TeatroOK.totalVendido);
        System.out.println("\n");
    }
    
    //Método Limpiar los datos del sistema
    public void limpiarDatos(){
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 10; j++) {
                espacios[i][j].estadoCliente = Estados.Disponible;
             }
        }
        TeatroOK.teclado.close();
    }
}
