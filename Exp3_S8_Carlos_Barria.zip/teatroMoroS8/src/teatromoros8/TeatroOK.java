
package teatromoros8;

import java.util.Scanner;

/**
 *
 * 
 * Fecha: 22 abril 2024
 * Integrante: Sebastian Andres Cortes Negrete
 *             Carlos Alberto Barría Valdevenito
 * 
 * Actividad Formativa 7a Semana
 */
public class TeatroOK {
    static Scanner teclado = new Scanner(System.in);
    static int totalEntradas;
    static double totalVendido;
        
    public static void main(String[] args) {
        
        menu();
    }
    
    //Metodo Menu principal
    public static void menu() {
        //Inicializacion de Variables Clase Estáticas
        TeatroOK.totalEntradas = 0;
        TeatroOK.totalVendido = 0;

        //Inicialización de Variables Locales
        Proceso proceso = new Proceso();
        boolean deseaSalir;
        int opcion;
        
        //Ciclo do para ejecución de Menu con opciones
        do {
            System.out.println("*** Bienvenido al Teatro MORO ***");
            System.out.println("    ----- Menu Principal -----     ");
            System.out.println("|   1.- Comprar de Ticket.         |");
            System.out.println("|   2.- Resumen de Ventas.         |");
            System.out.println("|   3.- Generar Boleta.            |");
            System.out.println("|   4.- Modificar Ticket.          |");
            System.out.println("|   5.- Eliminar Ticket.           |");
            System.out.println("|   6.- Calcular Ingresos Totales. |");
            System.out.println("|   7.- Salir del Sistema.         |");
            System.out.print("  Seleccion su opcion: ");
            opcion = teclado.nextInt();
            
            switch (opcion) {
                case 1 -> {
                    //Venta de Entradas
                    System.out.println("\n");
                    System.out.println("Proceso de Compra Valor Gral $35000");
                    proceso.showAsientos();
                    proceso.Vender();
                    System.out.println("------------------------ Gracias");
                    System.out.println();
                    deseaSalir = false;
                }
                case 2 -> {
                    //Resumen de Ventas
                    System.out.println("\n");
                    proceso.showAsientos();
                    proceso.resumenVentas();
                    deseaSalir = false;
                }
                case 3 -> {
                    //Generar Boleta
                    System.out.println("\n");
                    proceso.GenerarBoleta();
                    
                    System.out.println();
                    TeatroOK.totalEntradas = 0;
                    TeatroOK.totalVendido = 0;
                    deseaSalir = false;
                }
                case 4 -> {
                    //Modificar Ticket
                    System.out.println("\n");
                    proceso.modificarTicket();
                    System.out.println();
                    TeatroOK.totalEntradas = 0;
                    TeatroOK.totalVendido = 0;
                    deseaSalir = false;
                }
                case 5 -> {
                    //Eliminar Ticket
                    System.out.println("\n");
                    proceso.eliminaTicket();
                    System.out.println();
                    TeatroOK.totalEntradas = 0;
                    TeatroOK.totalVendido = 0;
                    deseaSalir = false;
                }
                case 6 -> {
                    //Calcular Ingresos Totaltes
                    System.out.println("\n");
                    proceso.EstadoVentas();
                    TeatroOK.totalEntradas = 0;
                    TeatroOK.totalVendido = 0;
                    deseaSalir = false;
                }
                case 7 -> {
                    deseaSalir = true;
                    System.out.println("Gracias por su visita, vuelva pronto.");
                }
                default -> {
                    System.out.println("Opcion no valida, intente nuevamente");
                    deseaSalir = false;
                }
            }
        } while (deseaSalir != true);
        
        //Limpieza de datos
        proceso.limpiarDatos();
    }
}
