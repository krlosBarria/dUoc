package com.duoc.entidades;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 08 julio 2024 
 * @asignatura:  
 *
 */
class lock {

}
