package com.duoc.entidades;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 08 julio 2024
 * @asignatura:Desarrollo Orientado Objeto I
 * @actividad: Actividad Sumativa S8
 *
 */
public class PrimesThread implements Runnable {

    @Override
    public synchronized void run() {
        int numRandom;
        PrimesList listaPrimos = new PrimesList();

        long inicia = System.currentTimeMillis(); //Captura tiempo incio
        numRandom = (int) (Math.random() * 100);
        System.out.println("El numero aleatorio es: " + numRandom);
        if (listaPrimos.isPrime(numRandom)) {
            System.out.println("Lo agrega al arreglo de NumPrimos");
            listaPrimos.add(numRandom);
        } else {
            System.out.println("no es primo");
        }

        try {
            Thread.sleep(3000); //deja hilo con pausa de 3000 milisegundos
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long termina = System.currentTimeMillis(); //Captura tiempo final

        //Convertir a segundos
        double inicioSeg = inicia / 1000.0;
        double terminoSeg = termina / 1000.0;

        System.out.println("Inicio: " + inicioSeg + " Segundos.");
        System.out.println("Termino: " + terminoSeg + " Segundos.");
        System.out.println("Total: " + (terminoSeg - inicioSeg) / 1000.0 + " Segundos.");
    }
}
