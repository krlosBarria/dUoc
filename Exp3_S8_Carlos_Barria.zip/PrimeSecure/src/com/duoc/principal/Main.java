package com.duoc.principal;

import com.duoc.entidades.PrimesList;
import com.duoc.entidades.PrimesThread;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 08 julio 2024
 * @asignatura: Desarrollo Orientado Objeto I
 * @activdad: Actividad Sumativa S8
 *
 */
public class Main {

    private static final Scanner teclado = new Scanner(System.in);
    private static int opcion;
    private static PrimesList primosLista = new PrimesList();

    public static void main(String[] args) {
        do {
            menuPri();
            try {
                opcion = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Servidor detecta ingreso no valido");
                opcion = 0;
                teclado.next();  //limpiar buffer
            }
            switch (opcion) {
                case 1 ->
                    codigoPrimo();
                case 2 ->
                    cargarPrimosCSV();
                case 3 ->
                    encriptarArchivoTexto();
                case 4 ->
                    mostrarNumerosPrimos();
                case 5 ->
                    ejecucionHilos();
                case 6 ->
                    System.out.println("Goodbye");
                default ->
                    System.out.println("Opcion fuera de rango");
            }
        } while (opcion != 6);
        teclado.close();
    }

    //Menú Principal
    private static void menuPri() {
        String s;
        s = """
        +++++ PrimeSecure ++++++++++++
            1.- Asignar codigo primo.
            2.- Cargar Numeros Primos en CSV.
            3.- Encriptar a un archivo Texto.
            4.- Mostrar Numeros.
            5.- Ejecute hilos [start()&join()].
            6.- Salir.
        Seleccione su opcion:""";
        System.out.println(s);
    }

    //Método codigoPrimo() ==> opcion01
    private static void codigoPrimo() {
        System.out.print("Ingrese un numero entero (0 para finalizar): ");
        int numero = teclado.nextInt();

        while (numero != 0) {
            try {
                primosLista.add(numero);
                System.out.println(numero + " se agrega a la lista de Num Primos");

            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            }
            System.out.println("Ingrese otro numero entero (0 para fin): ");
            numero = teclado.nextInt();
        }
        System.out.println("Lista de numeros Primos:" + primosLista);
        System.out.println("Total numeros Primos en la lista es: " + primosLista.getPrimesCount());
    }

    //Método carga Numeros Primos desde archivo CSV ==> opción02
    private synchronized static void cargarPrimosCSV() {
        char opCarga = 0;

        System.out.print("Desea cargar Numeros Primos desde archivo 'numeros.csv'? (S/N) ");
        opCarga = teclado.next().toUpperCase().charAt(0); //Convierte la entrada en Mayúscula
        if (opCarga == 'S') {
            // Cargar libros desde el archivo CSV
            List<Integer> listaPrimosCSV = leerNumPrimosDesdeCSV("numeros.csv");

            //Collecion sincronizada
            List<Integer> syncList = Collections.synchronizedList(listaPrimosCSV);

            System.out.println("Conteo Numeros Primos: " + primosLista.getPrimesCount());
            System.out.println("La lista sincronizada : " + syncList);

        } else {
            if (opCarga == 'N') {
                System.out.println("No se ha cargado archivo CSV ==> numeros.csv");
            }
            System.out.println("Opcion no valida, see your later");
        }
    }

    //Método leer los datos desde un archivo CSV ==> cargarPrimosCSV() 
    private synchronized static List<Integer> leerNumPrimosDesdeCSV(String archivoCSV) {
        List<Integer> listaNumPriX = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] numComoString = line.split(",");

                for (String dato : numComoString) {
                    int numero = Integer.parseInt(dato.trim());
                    listaNumPriX.add(numero);
                    primosLista.add(numero);
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer archivo CSV " + e.getMessage());
        }
        return listaNumPriX;
    }

    //Método encripta a un archivo de texto ==> opcion03
    private synchronized static void encriptarArchivoTexto() {
        String archivoTexto = "numerosEncrip.txt";
        if (primosLista.isEmpty()) {
            System.out.println("Sin Datos!!!. No ha cargado o ingresado numeros.");
        } else {

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoTexto, true))) {
                for (Integer dato : primosLista) {
                    int numEncriptado = encriptar(dato);
                    bw.write(String.valueOf(numEncriptado));
                    bw.newLine();
                }
                System.out.println("Conteo de N Primos: " + primosLista.getPrimesCount());
                System.out.println("Archivo " + archivoTexto + " Encriptado y creado con exito.");

            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    //Metodo encripta usando XOR con clave sencilla ==> encriptarArchivoTexto()
    public static int encriptar(int numero) {
        int clave = 123;    //acá la clave
        return numero ^ clave;
    }

    //Método para mostrar los datos cargados o no ==> opción04
    private static void mostrarNumerosPrimos() {

        if (primosLista.isEmpty()) {
            System.out.println("Sin Datos!!!. No ha cargado o ingresado numeros.");
        } else {
            System.out.println("Conteo de Numeros Primos cargados: " + primosLista.getPrimesCount());
            System.out.println("Numeros Cargados: " + primosLista);
        }
    }

    //Método ejecuta hilos con las clasesPrimesThread ==> opción05
    private static void ejecucionHilos() {

        PrimesThread inter1 = new PrimesThread();

        Thread hilo1 = new Thread(inter1);
        Thread hilo2 = new Thread(inter1);

        hilo1.start();
        hilo2.start();

        try {
            // Esperamos a que los hilos terminen
            hilo1.join();
            hilo2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Todos los hilos han terminado. Fin del programa.");

    }
}
