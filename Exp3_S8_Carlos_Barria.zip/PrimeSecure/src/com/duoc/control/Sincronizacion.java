package com.duoc.control;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 08 julio 2024 
 * @asignatura:Desarrollo Orientado Objeto I
 * @actividad: Actividad Sumativa S8
 *
 */
public class Sincronizacion {

    private boolean condicion = false;

    public synchronized void esperar() throws InterruptedException {
        while (!condicion) {
            wait(); // El hilo se queda esperando hasta que se llame a notify()
        }
        System.out.println("Hola mundo");
    }

    public synchronized void notificar() {
        condicion = true;
        notify(); // Notificar a un hilo en espera que puede continuar
    }
}