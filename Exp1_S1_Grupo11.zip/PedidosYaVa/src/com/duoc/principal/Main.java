package com.duoc.principal;

import com.duoc.entidades.Singleton;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 12, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa S1 - Grupo 11
 *
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("Bienvenidos a Pedidos Ropa On-Line - YaVa");
        
        //Lines de Prueba para chequeo de Singleton
        Thread hilo1 = new Thread(new Runnable() {
            @Override
            public void run() {
                Singleton codigoHash = Singleton.getSingleton();
                System.out.println("1. HashCode asignado = " + codigoHash.hashCode());
            }
        });
        
        Thread hilo2 = new Thread(new Runnable() {
            @Override
            public void run() {
                Singleton codigoHash2 = Singleton.getSingleton();
                System.out.println("2. HashCode asignado = " + codigoHash2.hashCode());
            }
        });

        hilo1.start();
        hilo2.start();
    }
}
