
package com.duoc.entidades;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 12, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa S1 - Grupo 11
 *
 */
public class DiscountManager {

    //Constructor privado para evitar instancias indirectas
    private DiscountManager() {
    }
}
