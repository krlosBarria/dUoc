
package teatrook;

//
public enum Estados {
    Disponible,
    Ocupado
}
