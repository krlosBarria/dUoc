
package teatrook;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Carlos Barria Valdevenito
 * Fecha: Lunes 15 abril 2024
 * 
 * Actividad Sumativa 6ta Semana
 */

public class TeatroOK {
    //Definición de Varíables de Clase Estáticas
    static Scanner teclado = new Scanner(System.in);
    static int totalEntradas;
    static double totalVendido;
    
    //Método Main 
    public static void main(String[] args) {
        
        menu();
    }
    
    //Metodo Menu principal
    public static void menu() {
        //Inicializacion de Variables Clase Estáticas
        TeatroOK.totalEntradas = 0;
        TeatroOK.totalVendido = 0;

        //Inicialización de Variables Locales
        Proceso proceso = new Proceso();
        boolean deseaSalir;
        int opcion;
        
        //Ciclo do para ejecución de Menu con opciones
        do {
            System.out.println("Bienvenido al Teatro Moto");
            System.out.println("Menu Principal ");
            System.out.println("1.- Comprar Entradas");
            System.out.println("2.- Ver Asientos");
            System.out.println("3.- Estado de Ventas.");
            System.out.println("4.- Detalles Ventas.");
            System.out.println("5.- Salir del Sistema.");
            System.out.println("Seleccion su opcion");
            opcion = teclado.nextInt();
            
            switch (opcion) {
                case 1 -> {
                    System.out.println("Proceso de Compra Valor Gral $35000");
                    proceso.showAsientos();
                    proceso.Vender();
                    proceso.showAsientos();
                    
                    // Metodo Sleep para dejar una pausa de 3 Segundo y continuar
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(TeatroOK.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    deseaSalir = false;
                }
                case 2 -> {
                    TeatroOK.totalEntradas = 0;
                    TeatroOK.totalVendido = 0;
                    proceso.showAsientos();
                    
                    // Metodo Sleep para dejar una pausa de 3 Segundo y continuar
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(TeatroOK.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    deseaSalir = false;
                }
                case 3 -> {
                    TeatroOK.totalEntradas = 0;
                    TeatroOK.totalVendido = 0;
                    proceso.EstadoVentas();

                    /*                    // Metodo Sleep para dejar una pausa de 3 Segundo y continuar
                    try {
                    Thread.sleep(3000);
                    } catch (InterruptedException ex) {
                    Logger.getLogger(TeatroOK.class.getName()).log(Level.SEVERE, null, ex);
                    }*/
                    deseaSalir = false;
                }
                case 4 -> {
                    TeatroOK.totalEntradas = 0;
                    TeatroOK.totalVendido = 0;
                    System.out.println("===== Detalle de Entradas Vendidas =====");
                    proceso.detalleVentas();
                    System.out.println("Cantidad de Entradas Vendidas: "+TeatroOK.totalEntradas);
                    System.out.println("Total de Ventas: "+TeatroOK.totalVendido);
                    System.out.println("========================================");
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 5 -> {
                    deseaSalir = true;
                    System.out.println("Gracias por su visita, vuelva pronto.");
                }
                default -> {
                    System.out.println("Opcion no valida, intente nuevamente");
                    deseaSalir = false;
                }
            }
        } while (deseaSalir != true);
        
        //Limpieza de datos
        proceso.limpiarDatos();
    }
}
