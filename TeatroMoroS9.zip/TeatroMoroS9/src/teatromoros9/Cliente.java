package teatromoros9;

public class Cliente {
    public int idVenta;
    public String nomCliente;
    public String entradaCliente;
    public String nomEventoCliente;
    public int  edadCliente, asientoCliente;
    public double pagoCliente,descCliente;
    
    
    public Estados estadoCliente;
    
    public Cliente(){
        idVenta=-1;
        nomCliente = "";
        entradaCliente = "";
        nomEventoCliente = "";
        asientoCliente = 0;
        edadCliente = 0;
        pagoCliente = 0;
        descCliente = 0;
        estadoCliente = Estados.Disponible;
    }
}
