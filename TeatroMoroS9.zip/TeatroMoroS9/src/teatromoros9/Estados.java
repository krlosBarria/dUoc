
package teatromoros9;

//
public enum Estados {
    Disponible,
    Ocupado
}
