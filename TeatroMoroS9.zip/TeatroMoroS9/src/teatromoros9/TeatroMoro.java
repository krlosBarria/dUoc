
package teatromoros9;

import java.util.Scanner;
import java.util.List;
import java.util.Arrays;

/**
 * Fecha: 5 Mayo 2024
 * Integrante: Carlos Alberto Barría Valdevenito
 * 
 * Evaluación Final Transversal 9ª Semana 
 * URLGithub: https://github.com/krlosBarria/dUoc
 */
public class TeatroMoro {
    static Scanner teclado = new Scanner(System.in);
    static List<String> otraU = Arrays.asList("Vip", "Platea", "Balcon");
    static String nombreEvento = "Iron Maiden";
    static int totalEntradas;
    static double totalVendido, valorEvento = 35000;
    
        
    public static void main(String[] args) {
        
        menu();
    }
    
    //Metodo Menu principal
    public static void menu() {
        //Inicializacion de Variables Clase Estáticas
        TeatroMoro.totalEntradas = 0;
        TeatroMoro.totalVendido = 0;

        //Inicialización de Variables Locales
        Proceso proceso = new Proceso();
        boolean deseaSalir = false;
        int opcion;
        
        //Ciclo do para ejecución de Menu con opciones
        do {
            System.out.println("*** Bienvenido al Teatro MORO ***");
            System.out.println("    ----- Menu Principal -----     ");
            System.out.println("|   1.- Comprar de Ticket.         |");
            System.out.println("|   2.- Resumen de Ventas.         |");
            System.out.println("|   3.- Generar Boleta.            |");
            System.out.println("|   4.- Modificar Ticket.          |");
            System.out.println("|   5.- Eliminar Ticket.           |");
            System.out.println("|   6.- Calcular Ingresos Totales. |");
            System.out.println("|   7.- Configuracion de Eventos.  |");
            System.out.println("|   8.- Salir del Sistema.         |");
            System.out.print("  Seleccion su opcion: ");
            
            try {
                opcion = teclado.nextInt();
            } catch (Exception e) {
                System.out.println("*** Opcion No valida ***");
                opcion = 0;
                teclado.next(); //Limpiamos el buffer del scanner
            }
            
            switch (opcion) {
                case 1 -> {
                    //Venta de Entradas
                    proceso.showAsientos();
                    proceso.Vender();
                    System.out.println("------------------------ Gracias");
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 2 -> {
                    //Resumen de Ventas
                    proceso.showAsientos();
                    proceso.resumenVentas();
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 3 -> {
                    //Generar Boleta
                    proceso.GenerarBoleta();
                    TeatroMoro.totalEntradas = 0;
                    TeatroMoro.totalVendido = 0;
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 4 -> {
                    //Modificar Ticket
                    proceso.modificarTicket();
                    TeatroMoro.totalEntradas = 0;
                    TeatroMoro.totalVendido = 0;
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 5 -> {
                    //Eliminar Ticket
                    proceso.eliminaTicket();
                    TeatroMoro.totalEntradas = 0;
                    TeatroMoro.totalVendido = 0;
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 6 -> {
                    //Calcular Ingresos Totaltes
                    proceso.EstadoVentas();
                    TeatroMoro.totalEntradas = 0;
                    TeatroMoro.totalVendido = 0;
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 7 -> {
                    //Configuracion de Eventos
                    proceso.configuracionEvento();
                    TeatroMoro.totalEntradas = 0;
                    TeatroMoro.totalVendido = 0;
                    System.out.println("\n");
                    deseaSalir = false;
                }
                case 8 -> {
                    deseaSalir = true;
                    System.out.println("Gracias por su visita, vuelva pronto.");
                }
                default -> {
                    System.out.println("Opcion fuera de rango.\n");
                }
            }
        } while (deseaSalir != true);
        
        //Limpieza de datos
        proceso.limpiarDatos();
    }
}
