package teatromoros9;

import static teatromoros9.TeatroMoro.otraU;

public class Proceso {

    Cliente espacios[][] = new Cliente[3][10];
    boolean tieneVentas;

    //Creacion de clase Cliente para almacenar los datos del arreglo
    public Proceso() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 10; j++) {
                espacios[i][j] = new Cliente();
            }
        }
    }

    //01 Metodo de compra de Tickets (Función)
    public void Vender() {
        int idVenta;
        String nombre;
        String tipoUbi;
        boolean filaOk = false;
        boolean asientoOk = false;
        int edad = 0;
        int fila = 0;
        int asiento = 0;

        System.out.println("Ingrese su nombre: ");
        TeatroMoro.teclado.nextLine();  //borrar buffer de scanner
        nombre = TeatroMoro.teclado.nextLine();

        do {
            System.out.println("Ingrese su Edad: ");
            try {
                edad = TeatroMoro.teclado.nextInt();
            } catch (Exception e) {
                System.out.println("Solo Numeros Enteros positivos " + edad + ", error " + e);
                TeatroMoro.teclado.next();   //limpiar buffer de scanner
            }
        } while (edad == 0);

        // Ciclo Validación de selección de filas
        do {
            System.out.println("Seleccione la Ubicacion  ");
            System.out.println("[1=" + otraU.get(0) + ", 2=" + otraU.get(1) + ", 3=" + otraU.get(2) + "]");
            try {
                fila = TeatroMoro.teclado.nextInt();

                //Verificación valor de Fila
                if (fila >= 1 && fila <= 3) {
                    filaOk = true;

                    // Ciclo Validación de selección de Asiento
                    do {
                        System.out.println("Seleccione el asiento [1..10] :");
                        try {
                            asiento = TeatroMoro.teclado.nextInt();
                            tipoUbi = otraU.get(fila - 1);

                            //Verificación valor de Asiento
                            if (asiento >= 1 && asiento <= 10) {
                                asientoOk = true;

                                //Verificacion de disponibilidad de ubicacion disponible
                                if (espacios[fila - 1][asiento - 1].estadoCliente == Estados.Disponible) {
                                    espacios[fila - 1][asiento - 1].nomCliente = nombre;
                                    espacios[fila - 1][asiento - 1].edadCliente = edad;
                                    espacios[fila - 1][asiento - 1].entradaCliente = tipoUbi;
                                    System.out.println("=====================================");
                                    System.out.println("    Datos de tu compra");
                                    System.out.println("=====================================");
                                    if (edad <= 18) {
                                        espacios[fila - 1][asiento - 1].pagoCliente = TeatroMoro.valorEvento - (TeatroMoro.valorEvento * 0.10);
                                        espacios[fila - 1][asiento - 1].descCliente = (0.10);
                                        espacios[fila - 1][asiento - 1].asientoCliente = asiento;
                                        espacios[fila - 1][asiento - 1].nomEventoCliente = TeatroMoro.nombreEvento;
                                        System.out.println("Nombre Evento: " + TeatroMoro.nombreEvento);
                                        System.out.println("Ubicacion: " + tipoUbi + " Asiento: " + asiento);
                                        System.out.println("Descuento Estudiante 10% $" + (TeatroMoro.valorEvento * 0.10));
                                        System.out.println("Total a Pagar: $" + espacios[fila - 1][asiento - 1].pagoCliente);
                                    } else {
                                        if (edad >= 60) {
                                            espacios[fila - 1][asiento - 1].pagoCliente = TeatroMoro.valorEvento - (TeatroMoro.valorEvento * 0.15);
                                            espacios[fila - 1][asiento - 1].descCliente = (0.15);
                                            espacios[fila - 1][asiento - 1].asientoCliente = asiento;
                                            espacios[fila - 1][asiento - 1].nomEventoCliente = TeatroMoro.nombreEvento;
                                            System.out.println("Nombre Evento: " + TeatroMoro.nombreEvento);
                                            System.out.println("Ubicacion: " + tipoUbi + " Asiento: " + asiento);
                                            System.out.println("Descuento 3era Edad 15% $" + (TeatroMoro.valorEvento * 0.15));
                                            System.out.println("Total a Pagar: $" + espacios[fila - 1][asiento - 1].pagoCliente);
                                        } else {
                                            espacios[fila - 1][asiento - 1].pagoCliente = TeatroMoro.valorEvento;
                                            espacios[fila - 1][asiento - 1].descCliente = 0;
                                            espacios[fila - 1][asiento - 1].asientoCliente = asiento;
                                            espacios[fila - 1][asiento - 1].nomEventoCliente = TeatroMoro.nombreEvento;
                                            System.out.println("Nombre Evento: " + TeatroMoro.nombreEvento);
                                            System.out.println("Ubicacion: " + tipoUbi + " Asiento: " + asiento);
                                            System.out.println("No Aplica Descuento");
                                            System.out.println("Total a Pagar: $" + espacios[fila - 1][asiento - 1].pagoCliente);
                                        }
                                    }
                                    espacios[fila - 1][asiento - 1].estadoCliente = Estados.Ocupado;
                                    idVenta = (int) (Math.random() * 100 + 1);    //Genera ID de venta de forma aleatoria
                                    espacios[fila - 1][asiento - 1].idVenta = idVenta;
                                    System.out.println("Codigo de Ticket: " + idVenta);
                                    System.out.println("El Ticket de asiento esta reservado\n");
                                } else {
                                    System.out.println("El Asiento no esta disponible");
                                }
                            } else {
                                System.out.println("Asiento ingresado no valido.");
                                System.out.println("Favor ingresar numero Asiento [1 a 10].");
                            }
                        } catch (Exception e) {
                            System.out.println("Solo Numeros Enteros positivos " + asiento + ", error " + e);
                            TeatroMoro.teclado.next();   //limpiar buffer de scanner
                        }
                    } while (asientoOk != true);
                } else {
                    System.out.println("Valor ingresado no valido.");
                    System.out.println("Favor ingresar nuevamente Fila [1 a 3].");
                }
            } catch (Exception e) {
                System.out.println("Solo Numeros Enteros positivos " + fila + ", error " + e);
                TeatroMoro.teclado.next();   //limpiar buffer de scanner
            }
        } while (filaOk != true);
    }

    //02 Resumen de Ventas [Ubicacion, Costo Final y descuentos (Función)
    public void resumenVentas() {

        vendimos();
        if (tieneVentas) {
            System.out.println(" Resumen de Ventas");
            System.out.println(" =====================================");
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 10; j++) {
                    if (espacios[i][j].estadoCliente != Estados.Disponible) {
                        System.out.println(" Codigo Ticket: " + espacios[i][j].idVenta);
                        System.out.println(" Ubicacion: " + espacios[i][j].entradaCliente + ", asiento: " + espacios[i][j].asientoCliente);
                        System.out.println(" Nombre: " + espacios[i][j].nomCliente);
                        System.out.println(" Edad: " + espacios[i][j].edadCliente);
                        System.out.println(" Descuento: " + espacios[i][j].descCliente + "%");
                        System.out.println(" Costo Final: $" + espacios[i][j].pagoCliente);
                        System.out.println(" -------------------------------------");
                    }
                }
            }
        } else {
            System.out.println("Sin ventas aun, nada que Informar. Saludos.");
        }
    }

    //03 Generar Boleta (Función)
    public void GenerarBoleta() {

        vendimos();
        if (tieneVentas) {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 10; j++) {
                    if (espacios[i][j].estadoCliente != Estados.Disponible) {
                        System.out.println("*************************************");
                        System.out.println("------ Boleta Teatro Moro -----------");
                        System.out.println("Codigo Ticket: " + espacios[i][j].idVenta);
                        System.out.println("Ubicacion: " + espacios[i][j].entradaCliente);
                        System.out.println("Numero de asiento: " + espacios[i][j].asientoCliente);
                        System.out.println("Costo Base: $" + TeatroMoro.valorEvento);
                        System.out.println("Descuento Aplicado: " + espacios[i][j].descCliente + "%");
                        System.out.println("Costo Final : $" + espacios[i][j].pagoCliente);
                        System.out.println("   --- Gracias por su preferencia ---");
                    }
                }
            }
        } else {
            System.out.println("Sin ventas aun, a comprar se ha dicho");
            System.out.println();
        }
    }

    //04 Modifica Ticket (Función)
    public void modificarTicket() {
        int codigoTicket;
        String nuevoNombre;

        vendimos();
        if (tieneVentas) {
            System.out.println("Ingrese numero de ticket: ");
            try {
                codigoTicket = TeatroMoro.teclado.nextInt();
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 10; j++) {
                        if (espacios[i][j].idVenta == codigoTicket) {
                            System.out.println("--------------------------------");
                            System.out.println("--- Datos Ticket a Modificar ---");
                            System.out.println("--------------------------------");
                            System.out.println("Codigo Ticket: " + espacios[i][j].idVenta);
                            System.out.println("Nombre Asignado: " + espacios[i][j].nomCliente);
                            System.out.print("Ingrese el nuevo Nombre: ");
                            TeatroMoro.teclado.nextLine();
                            nuevoNombre = TeatroMoro.teclado.nextLine();
                            espacios[i][j].nomCliente = nuevoNombre;
                            /*
                        System.out.println("Numero de asiento: "+espacios[i][j].asientoCliente);
                        System.out.println("Costo Base: $"+TeatroMoro.valorEvento);
                        System.out.println("Descuento Aplicado: "+espacios[i][j].descCliente+"%");
                        System.out.println("Costo Final : $"+espacios[i][j].pagoCliente);
                             */
                            System.out.println("Modificacion de nombre realizada!");
                            System.out.println("\n");
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("Valor no valido, Solo numeros enteros");
                TeatroMoro.teclado.next();   //Limpia el buffer del scanner
            }
        } else {
            System.out.println("No existen Ventas, sin tickets para modificar!");
        }
    }

    //05 Eliminar Compra (Función)
    public void eliminaTicket() {
        int codigoTicket;

        vendimos();
        if (tieneVentas) {
            System.out.println("Ingrese numero de ticket: ");
            try {
                codigoTicket = TeatroMoro.teclado.nextInt();
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 10; j++) {
                        if (espacios[i][j].idVenta == codigoTicket) {
                            System.out.println("------ Datos Ticket a Eliminar-----------");
                            System.out.println("Codigo Ticket: " + espacios[i][j].idVenta);
                            System.out.println("Nombre Asignado: " + espacios[i][j].nomCliente);
                            System.out.println("Ubicacion: " + espacios[i][j].entradaCliente + ", Asiento: " + espacios[i][j].asientoCliente);
                            System.out.println("Costo Final : $" + espacios[i][j].pagoCliente);
                            System.out.println("--------------------------------------------");
                            System.out.println("*** Ticket Eliminado, asiento disponible ***");
                            System.out.println("--------------------------------------------");
                            espacios[i][j].estadoCliente = Estados.Disponible;
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("Valor no valido, Solo numeros enteros");
                TeatroMoro.teclado.next();   //Limpia el buffer del scanner
            }
        } else {
            System.out.println("No existen Ticket para Eliminar.");
        }
    }

    //06 Calcular Ingresos Totales de Ventas (Función)
    public void EstadoVentas() {
        String tipoFila;

        for (int i = 0; i < 3; i++) {
            tipoFila = otraU.get(i);
            System.out.println((i + 1) + " " + tipoFila);
            for (int j = 0; j < 10; j++) {
                if (espacios[i][j].estadoCliente == Estados.Disponible) {
                    System.out.print(" _ ");
                } else {
                    System.out.print(" X ");
                    TeatroMoro.totalEntradas++;
                    TeatroMoro.totalVendido = TeatroMoro.totalVendido + espacios[i][j].pagoCliente;
                }
            }
            System.out.println(" |");
            System.out.println("\n");
        }
        System.out.println("Nombre del Evento: " + TeatroMoro.nombreEvento);
        System.out.println("Cantidad de Entradas vendidas: " + TeatroMoro.totalEntradas);
        System.out.println("Por un total de $" + TeatroMoro.totalVendido);
    }

    //07 Configuracion de Eventos (Función)
    public void configuracionEvento() {
        char continuar = ' ';
        String val01, val02, val03;
        double nuevoValorEvento = 0;
        String nuevoEvento;

        System.out.println("--- Configuracion del Evento ---");
        System.out.println("Nombre Actual: " + TeatroMoro.nombreEvento);
        System.out.println("Valor Gral. Actual: " + TeatroMoro.valorEvento);
        System.out.println("Definicion de Ubicaciones");
        System.out.println("Seccion Fila 1: " + otraU.get(0));
        System.out.println("Seccion Fila 2: " + otraU.get(1));
        System.out.println("Seccion Fila 3: " + otraU.get(2));
        System.out.println("" + otraU);
        TeatroMoro.teclado.nextLine();  //consume buffer linea

        do {
            System.out.print("Desea modificar los datos del Evento? (s/n)");
            String desea = TeatroMoro.teclado.nextLine();
            if (desea.length() == 1) {
                continuar = desea.charAt(0);
                continuar = Character.toUpperCase(continuar);
            } else {
                System.out.println("Favor ingresar solo un caracter.");
            }
        } while (continuar != 'S' && continuar != 'N');

        System.out.println("El valor desea es: " + continuar);

        if (continuar == 'S') {
            System.out.println("Ingrese el Nombre Evento: ");
            nuevoEvento = TeatroMoro.teclado.nextLine();

            do {
                System.out.println("Ingrese el Valor General: ");
                try {
                    nuevoValorEvento = TeatroMoro.teclado.nextDouble();
                    TeatroMoro.teclado.nextLine();  //consume buffer linea 
                } catch (Exception e) {
                    System.out.println("Valor no valido, Solo numeros enteros Positivos");
                    TeatroMoro.teclado.next();   //Limpia el buffer del scanner
                }
            } while (nuevoValorEvento == 0);

            System.out.println("Definicion de Asientos");
            System.out.println("Seccion 1: ");
            val01 = TeatroMoro.teclado.nextLine();

            System.out.println("Seccion 2: ");
            val02 = TeatroMoro.teclado.nextLine();

            System.out.println("Seccion 3: ");
            val03 = TeatroMoro.teclado.nextLine();

            //Guarda los cambios en las variables
            TeatroMoro.nombreEvento = nuevoEvento;
            TeatroMoro.valorEvento = nuevoValorEvento;
            otraU.set(0, val01);
            otraU.set(1, val02);
            otraU.set(2, val03);
            System.out.println("" + otraU);
        } else {
            System.out.println("Los datos se mantienen.");
        }
        System.out.println("---------------------------------");
        System.out.println("***** INFORMACION de Evento *****");
        System.out.println("---------------------------------");
        System.out.println("Nombre Evento: " + TeatroMoro.nombreEvento);
        System.out.println("Valor Gral.: " + TeatroMoro.valorEvento);
        System.out.println("Secciones Ubicacion: " + otraU);
        System.out.println("---------------------------------");
    }

    //Función mostrar los asientos del Teatro
    public void showAsientos() {
        //String tipoFila;
        System.out.println("+++++++++++++++++++++++++++++++");
        System.out.println("Evento: " + TeatroMoro.nombreEvento + " Valor Gral: $" + TeatroMoro.valorEvento);
        System.out.println("--- Distribucion de Asientos ---");
        System.out.println(" 1  2  3  4  5  6  7  8  9  10 |");
        for (int i = 0; i < 3; i++) {
            System.out.println((i + 1) + " " + otraU.get(i));
            for (int j = 0; j < 10; j++) {
                if (espacios[i][j].estadoCliente == Estados.Disponible) {
                    System.out.print(" _ ");
                } else {
                    System.out.print(" X ");
                }
            }
            System.out.println(" |");
            System.out.println("\n");
        }
    }

    //Función que verifica si hay elementos en el arreglo espacios[][]
    public void vendimos() {
        tieneVentas = false;
        for (int ii = 0; ii < 3; ii++) {
            for (int j = 0; j < 10; j++) {
                if (espacios[ii][j].estadoCliente != Estados.Disponible) {
                    tieneVentas = true;
                }
            }
        }
    }

    //Método Limpiar los datos del sistema
    public void limpiarDatos() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 10; j++) {
                espacios[i][j].estadoCliente = Estados.Disponible;
            }
        }
        TeatroMoro.teclado.close();
    }
}
