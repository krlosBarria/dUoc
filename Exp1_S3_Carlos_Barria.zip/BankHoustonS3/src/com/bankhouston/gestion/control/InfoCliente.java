
package com.bankhouston.gestion.control;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 03 junio 2024 
 * @asignatura:  POO I
 *
 */
public interface InfoCliente {
    public void mostrarInformacionCliente();
    
}
