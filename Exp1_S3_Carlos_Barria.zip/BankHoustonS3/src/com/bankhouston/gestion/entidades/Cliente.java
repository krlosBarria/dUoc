package com.bankhouston.gestion.entidades;

/**
 *
* @author Carlos Barría Valdevenito 
 * Fecha: 3 junio 2024 Semana 3
 * Actividad Sumativa 
 * Ramo: Desarrollo POO I
 *
 */

public class Cliente {
    private String rut;
    private String nombre;
    private String apePaterno;
    private String apeMaterno;
    private String domicilio;
    private String comuna;
    private int telefono;
    //private int ctaCte;
    
    //metodo constructor
    public Cliente(String rut, String nombre, String apePaterno, String apeMaterno, String domicilio, String comuna, int telefono) {
        this.rut = rut;
        this.nombre = nombre;
        this.apePaterno = apePaterno;
        this.apeMaterno = apeMaterno;
        this.domicilio = domicilio;
        this.comuna = comuna;
        this.telefono = telefono;
        //this.ctaCte = ctaCte;
    }

    //Getter & Setter
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApePaterno() {
        return apePaterno;
    }

    public void setApePaterno(String apePaterno) {
        this.apePaterno = apePaterno;
    }

    public String getApeMaterno() {
        return apeMaterno;
    }

    public void setApeMaterno(String apeMaterno) {
        this.apeMaterno = apeMaterno;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

   
    //Metodos Comportamiento
    public String nombreCompleto(){
        return nombre+" "+apePaterno;
    }
    
    public String direccionCompleta(){
        return domicilio +", "+comuna;
    }
}
