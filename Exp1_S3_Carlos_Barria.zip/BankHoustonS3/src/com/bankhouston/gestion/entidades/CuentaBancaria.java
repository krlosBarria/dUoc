
package com.bankhouston.gestion.entidades;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;

/**
 * 
 * @author Carlos Barría Valdevenito 
 * Fecha: 3 junio 2024 Semana 3
 * Actividad Sumativa 
 * Ramo: Desarrollo POO I
 *
 */

public abstract class CuentaBancaria {
    
    public abstract String calcularInteres();
    private int numeroCuenta;
    private double saldo;
    private Cliente titular;
    private ArrayList<Movimiento> movimientos;  //Lista de transferencias
    
    //metodo constructor
    public CuentaBancaria(int numeroCuenta, double saldo, Cliente titular) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.titular = titular;
        this.movimientos = new ArrayList<Movimiento>();
    }

    //Getter & Setter
    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Cliente getTitular() {
        return titular;
    }

    public void setTitular(Cliente titular) {
        this.titular = titular;
    }
    
    //metodos comportamiento
    public void ingreso(double cantidad){   //Depositos
        //el ingreso debe ser positivo
        if (cantidad < 0){
            System.out.println("ERROR, no se puede ingresar una cantidad negativa");
            return;
        }
        saldo += cantidad;
        movimientos.add(new Movimiento(LocalDateTime.now(), cantidad, Movimiento.DEPOSITO));
    }
    
    public void retiro(float cantidad){ //Giros
        if (cantidad < 0) {
            System.out.println("Error, no se puede retirar una cantidad negativa");
            return;
        }
        
        if (cantidad > saldo) {
            System.out.println("Error, No hay suficiente Saldo");
            return;
        }
        saldo -= cantidad;
        movimientos.add(new Movimiento(LocalDateTime.now(), cantidad, Movimiento.GIRO));
    }
    
    ////////////////////////////////////
    //  Clase compuesta Movimiento    //
    ////////////////////////////////////
    private class Movimiento {
        private static final byte DEPOSITO = 0;
        private static final byte GIRO = 1;
        
        private LocalDateTime fechaHora;
        private double importe;
        private double saldoFinal;
        private byte tipo;

        public Movimiento(LocalDateTime fechaHora, double importe, byte tipo) {
            this.fechaHora = fechaHora;
            this.importe = importe;
            this.saldoFinal = saldo;
            this.tipo = tipo;
        }
        
        @Override
        public String toString() {
            return (tipo == DEPOSITO ? "DEPOSITO" : "GIRO")
                    + "[Fecha = " + fechaHora.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM))
                    + ", hora = " + fechaHora.format(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.MEDIUM))
                    + ", importe = " + importe
                    + ", saldo = " + saldoFinal + "$"
                    +"]";
        }
    }
    
    //metodo datos de las transacciones
    public String obtenerMovimientos() { 
        String s = "";
        for (Movimiento m : movimientos) {
            s += m.toString() + "\n";
        }
        return s;
    }

    //metodo mostrar los datos tranferencias de la cuenta específica
    public void verDatos() {
        String s = "";
        s += "NCuenta: " + numeroCuenta + "\n";
        s += "Titular: " + titular.nombreCompleto() + ", domicilio en " + titular.direccionCompleta() + "\n";
        s += "Saldo Actual: " + saldo + "$\n";
        s += "----  T R A N S F E R E N C I A S  -------------------------------\n";
        s += obtenerMovimientos();
        System.out.println(s);
    }
    
    @Override
    public String toString() {
        return "Cuenta [numeroCuenta=" + numeroCuenta + ", Titular=" + titular.nombreCompleto() + "]";
    }
    
}
