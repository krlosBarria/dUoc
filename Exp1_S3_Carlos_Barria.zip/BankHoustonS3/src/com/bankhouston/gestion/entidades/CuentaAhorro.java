package com.bankhouston.gestion.entidades;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 03 junio 2024 
 * @asignatura: POO I 
 *
 */
public class CuentaAhorro extends CuentaBancaria{

    public CuentaAhorro(int numeroCuenta, double saldo, Cliente titular) {
        super(numeroCuenta, saldo, titular);
    }

    @Override
    public String calcularInteres() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String calcularInteres(double valor) {
        System.out.println("No se aplica interes a la cta de ahorro");
        return null;
    }

    
}
