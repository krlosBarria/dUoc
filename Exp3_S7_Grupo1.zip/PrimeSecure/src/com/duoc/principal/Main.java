package com.duoc.principal;

import com.duoc.entidades.PrimesList;
import java.util.Scanner;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 01 julio 2024
 * @asignatura:POO I
 *  Actividad Formativa S7 Grupo 1
 *
 */
public class Main {

    public static void main(String[] args) {
        
        PrimesList primosLista = new PrimesList();
        Scanner teclado = new Scanner(System.in);

        System.out.print("Ingrese un numero entero (0 para finalizar): ");
        int numero = teclado.nextInt();
        
        while(numero != 0){
            try {
                primosLista.add(numero);
                System.out.println(numero+" se agrega a la lista de Num Primos");
                
            } catch (IllegalArgumentException e) {
                System.out.println("Error: "+e.getMessage());
            }
            System.out.println("Ingrese otro numero entero (0 para fin): ");
            numero = teclado.nextInt();
        }
        System.out.println("Lista de numeros Primos:"+primosLista);
        System.out.println("Total numeros Primos en la lista es: "+primosLista.getPrimesCount());
    }
}
