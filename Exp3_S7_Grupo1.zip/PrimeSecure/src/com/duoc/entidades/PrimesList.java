package com.duoc.entidades;

import java.util.ArrayList;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 01 julio 2024
 * @asignatura: POO I
 *  Actividad Formativa S7 Grupo 1
 *
 */
public class PrimesList extends ArrayList<Integer> {

    public PrimesList() {
    }

    //Método para verificar si es N° Primo
    public boolean isPrime(int numero) {

        if (numero <= 1) return false;
        if (numero == 2 || numero == 3) return true;
        if (numero % 2 == 0) return false;
        for (int i = 3; i *i <= numero; i+=2) {
            if (numero%i ==0) return false;
        }
        return true;
    }

    //Getter que traer el cantidad del arreglo de números primos
    public int getPrimesCount() {
        return this.size();
    }

    //Método agregar sobreescrito
    @Override
    public boolean add(Integer num) {
        if (isPrime(num)) {
            return super.add(num);
        } else {
            throw new IllegalArgumentException("Agrega, Solo numeros primos.");
        }
    }

    //Método eliminar sobreescrito
    @Override
    public boolean remove(Object num) {
        if (num instanceof Integer && isPrime((Integer) num)) {
            return super.remove(num);
        } else {
            throw new IllegalArgumentException("Solo numeros primos pueden ser eliminados ");
        }
    }
}
