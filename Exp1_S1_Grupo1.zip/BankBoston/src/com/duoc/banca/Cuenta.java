
package com.duoc.banca;

/**
 *
 * @author Carlos Barría Valdevenito
 * Grupo 01
 * Fecha: 20 Mayo 2024
 * Semana 1 Actividad Sumativa
 * Ramo: Desarrollo POO I
 * 
 */
public class Cuenta {
    private int numeroCuenta;
    private double saldo;
    private Cliente titular;
    
    //metodo constructor
    public Cuenta(int numeroCuenta, double saldo, Cliente titular) {
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
        this.titular = titular;
    }

    //Getter & Setter
    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Cliente getTitular() {
        return titular;
    }

    public void setTitular(Cliente titular) {
        this.titular = titular;
    }
    
    //metodos comportamiento
    public void ingreso(double cantidad){
        //el ingreso debe ser positivo
        if (cantidad < 0){
            System.out.println("ERROR, no se puede ingresar una cantidad negativa");
            return;
        }
        saldo += cantidad;
    }
    
    public void retiro(float cantidad){
        if (cantidad < 0) {
            System.out.println("Error, no se puede retirar una cantidad negativa");
            return;
        }
        
        if (cantidad > saldo) {
            System.out.println("Error, No hay suficiente Saldo");
            return;
        }
        saldo -= cantidad;
    }
}
