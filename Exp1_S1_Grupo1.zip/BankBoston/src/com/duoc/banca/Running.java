package com.duoc.banca;

import java.util.ArrayList;
import java.util.Scanner;
//import java.util.ArraysList;

/**
 *
 * @author Carlos Barría Valdevenito 
 * Grupo 01 
 * Fecha: 20 Mayo 2024 Semana 1
 * Actividad Sumativa Ramo: Desarrollo POO I
 *
 */
public class Running {
    
    private static Scanner teclado = new Scanner(System.in);
    private static String rutCli, nombreCli, apPatCli, apeMatCli, domicilioCli, comunaCli;
    private static int numCtaCli, telefonoCli, ctaCteCli, opcion;
    private static double saldoCli;
    private static ArrayList<Cliente> clientes = new ArrayList<>();
    private static Cuenta cuentas = null;
    private static int contadorCuenta = 1;
//    private static Cliente clientes[];

    public static void main(String[] args) {

        do {
            menuPri();
            //Validacion de opcion ingresada sea correcta
            try {
                opcion = teclado.nextInt();
            } catch (Exception e) {
                System.out.println("*** Opcion No valida ***");
                opcion = 0;
                teclado.next(); //Limpiamos el buffer del scanner
            }

            switch (opcion) {
                case 1 -> crearCliente();
                case 2 -> verDatos();
                case 3 -> depositar();
                case 4 -> girar();
                case 5 -> consultaSaldo();
                case 6 -> System.out.println("Gracias por su visita, Adios.");
                default -> System.out.println("Opcion fuera de rango.\n");
            }

        } while (opcion != 6);
        teclado.close();
    }

    static void menuPri() {
        String s = """
                  ------:Menu:------
                  1. Regsitrar Cliente
                  2. Ver datos Cliente
                  3. Depositar Dinero
                  4. Girar Dinero
                  5. Consultar Saldo
                  6. Salir
                  Seleccione su opcion:
                   """;
        System.out.println(s);
    }

    static void crearCliente() {
        System.out.println("Complete la informacion del Cliente");
        System.out.println("Rut: ");
        rutCli = teclado.nextLine();

        System.out.println("Nombres: ");
        nombreCli = teclado.nextLine();

        System.out.println("Apellido Paterno: ");
        apPatCli = teclado.nextLine();

        System.out.println("Apellido Materno: ");
        apeMatCli = teclado.nextLine();

        System.out.println("Domicilio: ");
        domicilioCli = teclado.nextLine();

        System.out.println("Comuna: ");
        comunaCli = teclado.nextLine();

        System.out.println("Telefono: ");
        telefonoCli = teclado.nextInt();

        System.out.println("Cuenta Corriente: ");
        ctaCteCli = teclado.nextInt();
        
        clientes.add(new Cliente(rutCli,nombreCli,apPatCli,apeMatCli,domicilioCli,comunaCli,telefonoCli,ctaCteCli));
    }
    
    static void verDatos(){
        int i;
        String nombre;
        
        if (clientes.isEmpty()) {
            System.out.println("vacio");
        }else{
            do {                
                i=0;
                
                System.out.println("El nombre será :"+clientes.get(i));
                System.out.println("todo "+clientes.addAll(clientes));
                
            } while (clientes.isEmpty());
            
            System.out.println("duuuuuuuuuuuuuuuu");
        }
    }
    
    static void depositar(){
    
    }
    
    static void girar(){
    }
    
    static void consultaSaldo(){
    }
}
