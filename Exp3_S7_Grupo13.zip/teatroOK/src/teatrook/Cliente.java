package teatrook;

public class Cliente {
    public String nomCliente;
    public String entradaCliente;
    public int  edadCliente, asientoCliente;
    public double pagoCliente,descCliente;
    
    public Estados estadoCliente;
    
    public Cliente(){
        nomCliente = "";
        entradaCliente = "";
        asientoCliente = 0;
        edadCliente = 0;
        pagoCliente = 0;
        descCliente = 0;
        estadoCliente = Estados.Disponible;
    }
}
