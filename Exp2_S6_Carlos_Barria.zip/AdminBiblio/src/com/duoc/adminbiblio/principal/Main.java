package com.duoc.adminbiblio.principal;

import com.duoc.adminbiblio.entidades.Libro;
import com.duoc.adminbiblio.entidades.Usuario;
import com.duoc.adminbiblio.excepciones.LibroNoEncontradoException;
import com.duoc.adminbiblio.excepciones.LibroYaPrestadoException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 24 junio 2024
 * @asignatura: DESARROLLO ORIENTADO A OBJETOS I
 *
 */
public class Main {

    private static final Scanner teclado = new Scanner(System.in);
    private static int opcion, telefonoSoc, edadSoc;
    private static String rutSoc, nombreSoc, apellidosSoc, direccionSoc, ciudadSoc;
    private static String tituloLibro, autorLibro;
    private static boolean estadoLibro;
    private static final ArrayList<Libro> libros = new ArrayList<>();   //ArrayList para Clase Libro
    private static Map<String, Usuario> sociosHM = new HashMap<>(); //HashMap para Clase Usuario(Socios)

    public static void main(String[] args) {
        do {
            menuPri();
            try {
                opcion = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Servidor detecta ingreso no valido");
                opcion = 0;
                teclado.next();  //limpiar buffer
            }
            switch (opcion) {
                case 1 ->
                    menuControlLibros();
                case 2 ->
                    buscarLibro();
                case 3 ->
                    prestarLibro();
                case 4 ->
                    menuControlSocios();
                case 5 ->
                    mostrarSocios();
                case 6 ->
                    System.out.println("Goodbye");
                default ->
                    System.out.println("Opcion fuera de rango");
            }
        } while (opcion != 6);
        teclado.close();
        libros.clear();
    }

    //Menú Principal
    private static void menuPri() {
        String s;
        s = """
        ----- Biblioteca Rotaria Valpo -----
            1.- Crear Registro de Libro.
            2.- Buscar Libro.
            3.- Prestamo de Libro.
            4.- Control de Socios (Usuarios).
            5.- Mostrar Socios.
            6.- Salir.
        Seleccione su opcion:""";
        System.out.println(s);
    }

    //SubMenú Libros.
    private static void menuLibros() {
        String s;
        s = """
        ----- Biblioteca Rotaria Valpo -----
            Menu - Libros:
            1.- Registrar Libros.
            2.- Modificar Libros.
            3.- Eliminar Libros.
            4.- Carga desde archivo CSV.
            5.- Volver MenuPrincipal.
        Seleccione su opcion:""";
        System.out.println(s);
    }

    //SubMenú Socios(Usuario).
    private static void menuSocios() {
        String s;
        s = """
        ----- Biblioteca Rotaria Valpo -----
            Menu - Socios:
            1.- Crear Socio.
            2.- Modificar Datos.
            3.- Eliminar Socio.
            4.- Volver MenuPrincipal.
        Seleccione su opcion:""";
        System.out.println(s);
    }

    //Mètodo SubMenu Control de Libros ==> Opcion 01
    public static void menuControlLibros() {

        do {
            menuLibros();
            try {
                opcion = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Servidor detecta ingreso no valido");
                opcion = 0;
                teclado.next();  //limpiar buffer
            }
            switch (opcion) {
                case 1 ->
                    registrarLibro();
                case 2 ->
                    modificarLibro();
                case 3 ->
                    eliminarLibro();
                case 4 ->
                    cargarLibrosCSV();
                case 5 ->
                    System.out.println("Vuelta a Menu Principal");
                default ->
                    System.out.println("Opcion fuera de rango");
            }
        } while (opcion != 5);
    }

    //Método Crear Registro de Libros ==> 01-01 
    private static void registrarLibro() {
        int estado = 0;
        char guardar = 0;
        boolean seguimos;

        System.out.println("--- Ingrese los datos del Libro ---");
        System.out.print("Titulo: ");
        teclado.nextLine();
        tituloLibro = teclado.nextLine();
        System.out.print("Autor: ");
        autorLibro = teclado.nextLine();

        do {
            System.out.print("Estado (1=disponible|2=prestado): ");
            try {
                estado = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Opcion no valida");
                teclado.next();
                estado = 0;
            }
            if (estado == 1) {
                estadoLibro = true;
            } else {
                if (estado == 2) {
                    estadoLibro = false;
                } else {
                    System.out.println("elija una opcion valida");
                    estado = 0;
                }
            }
        } while (estado == 0);

        do {
            //Guardar registro Libro
            System.out.print("Desea crear el registro del Libro? (Si/No): ");
            guardar = teclado.next().toUpperCase().charAt(0); //Convierte la entrada en Mayúscula

            //Verfica si la entrada es 'S' o 'N'
            if (guardar == 'S') {
                System.out.println("Registro Almacenado.");
                libros.add(new Libro(tituloLibro, autorLibro, estadoLibro));
                System.out.println(libros.toString());
                seguimos = true;
            } else {
                if (guardar == 'N') {
                    System.out.println("Sin registrar.");
                    seguimos = true;
                } else {
                    System.out.println("Por Favor, ingrese 'S' o 'N'.");
                    seguimos = false;
                }
            }
        } while (seguimos != true);
        System.out.println("\n=======================================");
    }

    //Método Modificar Registro de Libros ==> 01-02 
    private static void modificarLibro() {
        System.out.println("En Mantencion");
    }

    //Método Elimnar Registro de Libros ==> 01-03
    private static void eliminarLibro() {
        System.out.println("En Mantencion");
    }

    //Método carga Libros desde archivo CSV ==>01-04
    private static void cargarLibrosCSV() {
        char opCarga = 0;

        System.out.print("Desea cargar registros desde 'libros.csv'? (S/N) ");
        opCarga = teclado.next().toUpperCase().charAt(0); //Convierte la entrada en Mayúscula
        if (opCarga == 'S') {
            // Cargar libros desde el archivo CSV
            List<Libro> listaLibros = cargarLibrosDesdeCSV("libros.csv");

            //Mostrar lista de Libros cargados
            for (Libro librosx : listaLibros) {
                String disponibilidad = librosx.isEstado() ? "Disponible" : "Prestado";
                System.out.printf("Titulo: %s, Autor: %s, Estado: %s\n",
                        librosx.getTitulo(), librosx.getAutor(), disponibilidad);
                libros.add(librosx);    //carga lista en arrayList de Libros - quedo a modo de prueba
            }
        } else {
            if (opCarga == 'N') {
                System.out.println("No se ha cargado archivo CSV ==> libros.csv");
            }
            System.out.println("Opcion no valida, see your later");
        }
    }

    //Método leer los datos desde un archivo CSV
    private static List<Libro> cargarLibrosDesdeCSV(String archivoCSV) {
        List<Libro> librosx = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] datos = line.split(",");
                String tituloLib = datos[0].trim();
                String autorLib = datos[1].trim();
                boolean estadoLib = Boolean.parseBoolean(datos[2].trim());
                librosx.add(new Libro(tituloLib, autorLib, estadoLib));
            }

        } catch (IOException e) {
            System.err.println("Error al leer archivo CSV " + e.getMessage());
        }
        return librosx;
    }

    //Método Buscar libro ==> Opcion 02
    static void buscarLibro() {

        if (libros.isEmpty()) {
            try {
                //lanza Exception Personalizada
                throw new LibroNoEncontradoException();
            } catch (LibroNoEncontradoException ex) {
                System.out.println("No existen Libros - Excepcion Personalizada\n" + ex.toString());
            }
        } else {
            mostrarLibros();
            System.out.print("Ingrese nombre del libro a buscar: ");
            System.out.println("\n=======================================");
        }
    }

    //Método Prestar Libro ==> Opcion 03
    static void prestarLibro() {
        if (libros.isEmpty()) {
            try {
                //lanza Exception Personalizada
                throw new LibroYaPrestadoException();
            } catch (LibroYaPrestadoException ex) {
                System.out.println("No existen Libros para Prestar - Excepcion Personalizada\n" + ex.toString());
            }
        } else {
            System.out.println("--- Prestamo de Libros ---");
            System.out.println("\n=======================================");
            mostrarLibros();
        }
    }

    //SubMenu Control de Socios ==> Opcion 04
    public static void menuControlSocios() {

        do {
            menuSocios();
            try {
                opcion = teclado.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Servidor detecta ingreso no valido");
                opcion = 0;
                teclado.next();  //limpiar buffer
            }
            switch (opcion) {
                case 1 ->
                    crearUsuario();
                case 2 ->
                    modificarUsuario();
                case 3 ->
                    eliminarUsuario();
                case 4 ->
                    System.out.println("Vuelta a Menu Principal");
                default ->
                    System.out.println("Opcion fuera de rango");
            }
        } while (opcion != 4);
    }

    //Método Crear Socio Usuario ==> 04-01
    static void crearUsuario() {
        char guardamos = 0;
        boolean seguimos = false;
        boolean valorValido = false;

        System.out.println("--- Crear Registro de Socios---");
        System.out.print("Rut: ");
        teclado.nextLine();
        rutSoc = teclado.nextLine();

        System.out.print("Nombre: ");
        nombreSoc = teclado.nextLine();

        System.out.print("Apellidos: ");
        apellidosSoc = teclado.nextLine();

        System.out.print("Direccion: ");
        direccionSoc = teclado.nextLine();

        System.out.print("Ciudad: ");
        ciudadSoc = teclado.nextLine();

        do {
            System.out.print("Telefono: ");
            try {
                telefonoSoc = teclado.nextInt();
                valorValido = true;
            } catch (InputMismatchException ex) {
                System.out.println("Ingrese un valor valido para su telefono");
                teclado.next(); //Limpiar el buffer del teclado (scanner)
            }
        } while (valorValido != true);

        valorValido = false;
        do {
            System.out.print("Edad: ");
            try {
                edadSoc = teclado.nextInt();
                if (edadSoc < 14 || edadSoc > 100) {
                    System.out.println("La edad debe estar entre 14 y 100 ");
                } else {
                    valorValido = true;
                }
            } catch (InputMismatchException ex) {
                System.out.println("Debe ingresar una edad valida.");
                teclado.next(); //Limpiar el buffer del teclado (scanner)
            }
        } while (valorValido != true);

        do {
            //Guardar registro del Socio
            System.out.println("desea crear registro? Si/No: ");
            guardamos = teclado.next().toUpperCase().charAt(0); //Convierte la entrada en Mayúscula

            //Verfica si la entrada es 'S' o 'N'
            if (guardamos == 'S') {
                //Guardamos el registro en HashMap sociosHM
                sociosHM.put(rutSoc, new Usuario(rutSoc, nombreSoc, apellidosSoc, direccionSoc, ciudadSoc, telefonoSoc, edadSoc));
                //Guardar los datos del HashMap en un archivo txt csv
                grabarArchivoTexto();

                System.out.println("Registro Socio Creado");
                System.out.println(sociosHM.get(rutSoc));   //Muestra el registro guardado
                System.out.println("***** Enhorabuena, Ya eres Socio de Rotaria Valpo *****\n");
                seguimos = true;
            } else {
                if (guardamos == 'N') {
                    System.out.println("Sin registrar.");
                    seguimos = true;
                } else {
                    System.out.println("Por Favor, ingrese 'S' o 'N'.");
                    seguimos = false;
                }
            }
        } while (seguimos != true);
    }

    //Método Modificar datos del Socio(Usuario) ==> 04-02
    private static void modificarUsuario() {
        char desea = 0;
        boolean valorValido = false, seguimos = false;

        mostrarSocios();
        System.out.println("favor ingrese el rut del socio:");
        teclado.nextLine();
        rutSoc = teclado.nextLine();
        System.out.println("rut a modi: " + rutSoc);
        Usuario modificaSocio = sociosHM.get(rutSoc); //buscamos el rut del socio a modificar
        if (modificaSocio != null) {
            System.out.print("Nombre: [" + modificaSocio.getNomSocio() + "]: ");
            nombreSoc = teclado.nextLine();
            if ("".equals(nombreSoc)) {
                System.out.println("Sin modificar [" + (nombreSoc = modificaSocio.getNomSocio()) + "]");
            }

            System.out.print("Apellidos: [" + modificaSocio.getApeSocio() + "]: ");
            apellidosSoc = teclado.nextLine();
            if ("".equals(apellidosSoc)) {
                System.out.println("Sin modificar [" + (apellidosSoc = modificaSocio.getApeSocio()) + "]");
            }

            System.out.print("Direccion: [" + modificaSocio.getDireccionSoc() + "]: ");
            direccionSoc = teclado.nextLine();
            if ("".equals(direccionSoc)) {
                System.out.println("Sin modificar [" + (direccionSoc = modificaSocio.getDireccionSoc()) + "]");
            }

            System.out.print("Ciudad: [" + modificaSocio.getCiudadSoc() + "]: ");
            ciudadSoc = teclado.nextLine();
            if ("".equals(ciudadSoc)) {
                System.out.println("Sin modificar [" + (ciudadSoc = modificaSocio.getCiudadSoc()) + "]");
            }

            //Valida correcto ingreso de Telefono; sin embargo, no supe manejar solo presionar enter con los int no funciona
            do {
                System.out.print("Telefono: [" + modificaSocio.getTelefonoSoc() + "]: ");
                try {
                    telefonoSoc = teclado.nextInt();
                    valorValido = true;
                } catch (InputMismatchException ex) {
                    System.out.println("Ingrese un valor valido para su telefono");
                    teclado.next(); //Limpiar el buffer del teclado (scanner)
                }
            } while (valorValido != true);

            do {
                System.out.print("Edad: [" + modificaSocio.getEdadSoc() + "]: ");
                try {
                    edadSoc = teclado.nextInt();
                    valorValido = true;
                } catch (InputMismatchException ex) {
                    System.out.println("Ingrese un valor valido para su telefono");
                    teclado.next(); //Limpiar el buffer del teclado (scanner)
                }
            } while (valorValido != true);

            do {
                //Actualiza los cambios en el registro del Socio
                System.out.println("desea modificar los datos del registro? Si/No: ");
                desea = teclado.next().toUpperCase().charAt(0); //Convierte la entrada en Mayúscula

                //Verfica si la entrada es 'S' o 'N'
                if (desea == 'S') {
                    //Actualizamos los datos en registro en HashMap sociosHM
                    modificaSocio.setNomSocio(nombreSoc);
                    modificaSocio.setApeSocio(apellidosSoc);
                    modificaSocio.setDireccionSoc(direccionSoc);
                    modificaSocio.setCiudadSoc(ciudadSoc);
                    modificaSocio.setTelefonoSoc(telefonoSoc);
                    modificaSocio.setEdadSoc(edadSoc);
                    sociosHM.put(rutSoc, modificaSocio);    //Actualiza el registro en HashMap
                    System.out.println("Datos de Socio Actualizados");
                    System.out.println(sociosHM.get(rutSoc));   //Muestra el registro guardado
                    seguimos = true;
                } else {
                    if (desea == 'N') {
                        System.out.println("Sin registrar.");
                        seguimos = true;
                    } else {
                        System.out.println("Por Favor, ingrese 'S' o 'N'.");
                        seguimos = false;
                    }
                }
            } while (seguimos != true);
        } else {
            System.out.println("No se encontro al Rut del Socio." + rutSoc);
        }
    }

    //Método Elimina datos del Socio(Usuario)==> 04-03
    private static void eliminarUsuario() {

        mostrarSocios();
        System.out.println("favor ingrese el rut del socio:");
    }

    //Método informacion socios formato cuadrado ==> Opcion 05
    private static void mostrarSocios() {

        //Mostarr los registros con formato
        System.out.println("***** Registros de Socios *****");

        //Calcular el ancho máximo de cada campo para el formato cuadrado
        int maxRut = 0;
        int maxNombre = 0;
        int maxApellidos = 0;
        int maxDireccion = 0;
        int maxCiudad = 0;
        int maxTelefono = 0;
        int maxEdad = 0;

        for (Usuario socio : sociosHM.values()) {
            maxRut = Math.max(maxRut, socio.getRutSocio().length());
            maxNombre = Math.max(maxNombre, socio.getNomSocio().length());
            maxApellidos = Math.max(maxApellidos, socio.getApeSocio().length());
            maxDireccion = Math.max(maxDireccion, socio.getDireccionSoc().length());
            maxCiudad = Math.max(maxCiudad, socio.getCiudadSoc().length());
            maxTelefono = Math.max(maxTelefono, String.valueOf(socio.getTelefonoSoc()).length());
            maxEdad = Math.max(maxEdad, String.valueOf(socio.getEdadSoc()).length());
        }

        //Imprimir los registros con formato cuadrado
        String formato = "| %-" + (maxRut + 2) + "s| %-" + (maxNombre + 2) + "s| %-" + (maxApellidos + 2)
                + "s| %-" + (maxDireccion + 2) + "s| %-" + (maxCiudad + 2) + "s| %-" + (maxTelefono + 2) + "s| %-" + (maxEdad + 2) + "s|\n";

        //Imprimir La linea superior del formato
        System.out.format(formato, "Rut", "Nombre", "Apellidos", "Direccion", "Ciudad", "Telefono", "Edad");
        System.out.format(formato, "-".repeat(maxRut + 2), "-".repeat(maxNombre + 2), "-".repeat(maxApellidos + 2),
                "-".repeat(maxDireccion + 2), "-".repeat(maxCiudad + 2), "-".repeat(maxTelefono + 2), "-".repeat(maxEdad + 2));

        //Imprimir cada usuario en el formato cuadrado
        for (Usuario soc : sociosHM.values()) {
            System.out.format(formato, soc.getRutSocio(), soc.getNomSocio(), soc.getApeSocio(),
                    soc.getDireccionSoc(), soc.getCiudadSoc(), soc.getTelefonoSoc(), soc.getEdadSoc());
        }
        System.out.println("\n");
    }

    //Métodos mostrar Catalogo de libros
    private static void mostrarLibros() {
        int maxTitulo = 0;
        int maxAutor = 0;
        int maxDisponible = 0;

        for (Libro book : libros) {
            maxTitulo = Math.max(maxTitulo, book.getTitulo().length());
            maxAutor = Math.max(maxAutor, book.getAutor().length());
            maxDisponible = Math.max(maxDisponible, book.getAutor().length());
        }

        //Imprimir los registros con formato cuadrado
        String formato = "| %-" + (maxTitulo + 2) + "s| %-" + (maxAutor + 2) + "s| %-" + (maxAutor + 2)
                + "s|\n";

        System.out.format(formato, "Titulo", "Autor", "Disponibilidad");
        System.out.format(formato, "-".repeat(maxTitulo), "-".repeat(maxAutor), "-".repeat(maxDisponible));

        //imprimir cada Libro en el formato cuadrado
        for (Libro libro : libros) {
            System.out.format(formato, libro.getTitulo(), libro.getAutor(), libro.isEstado());
        }
        System.out.println("\n");

//        if (libros.isEmpty()) {
//            System.out.println("No existen libros");
//        } else {
//            for (Libro librox : libros) {
//                System.out.println("Titulo.: " + librox.getTitulo() + " Autor.: " + librox.getAutor() + " Disponible.: " + (librox.isEstado() ? "SI" : "NO"));
//            }
//        }
    }
    

    //Método grabar objetos en archivo texto
    private static void grabarArchivoTexto() {
        String archivo = "usuarios.txt"; //ruta archivo csv donde se almacenan los socios(Usuarios)

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true))) {
            for (Usuario datosSocios : sociosHM.values()) {
                bw.write(String.format("%s,%s,%s,%s,%s,%d,%d\n",
                        datosSocios.getRutSocio(),
                        datosSocios.getNomSocio(),
                        datosSocios.getApeSocio(),
                        datosSocios.getDireccionSoc(),
                        datosSocios.getCiudadSoc(),
                        datosSocios.getTelefonoSoc(),
                        datosSocios.getEdadSoc()));
            }
            System.out.println("Datos guardados en archivo");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
