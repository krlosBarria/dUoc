package com.duoc.adminbiblio.entidades;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 24 junio 2024 
 * @asignatura: DESARROLLO ORIENTADO A OBJETOS I
 *
 */
public class Biblioteca {
    private ArrayList<Libro> catalogoLibros;
    private HashMap<String, Usuario> usuariosResgitrados;
    private HashSet<Libro> librosPrestados;

    public Biblioteca(ArrayList<Libro> catalogoLibros, HashMap<String, Usuario> usuariosResgitrados, HashSet<Libro> librosPrestados) {
        this.catalogoLibros = catalogoLibros;
        this.usuariosResgitrados = usuariosResgitrados;
        this.librosPrestados = librosPrestados;
    }

    public Biblioteca() {
    }
    
    public void agregarLibro(Libro libro){
        catalogoLibros.add(libro);
    }
    
    public void eliminarLibro(Libro libro){
        catalogoLibros.remove(libro);
    }
    
    public ArrayList<Libro> getCataloLibros(){
        return catalogoLibros;
    }
    
    //Metodos para gestionar usaurios
    public void agregarUsuario(Usuario usuario){
        usuariosResgitrados.put(usuario.getRutSocio(), usuario);
    }
    
    public void eliminarUsuario(String codigoUsuario){
        usuariosResgitrados.remove(codigoUsuario);
    }
    
    public HashMap<String, Usuario> getUsuariosRegistrados(){
        return usuariosResgitrados;
    }
    
    //Métodos para préstamo y devolución de libros
    public boolean prestarLibro(Libro libro, Usuario user) {
        if(libro.isEstado()) {
            librosPrestados.add(libro);
            libro.setEstado(false);
            return true;
        }else{
            return false;
        }
    }
    
    public boolean devolverLibro(Libro libro) {
        if (librosPrestados.contains(libro)) {
            librosPrestados.remove(libro);
            libro.setEstado(true);
            return true;
        }else{
            return false;
        }
    }
    
    public HashSet<Libro> librosPrestados() {
        return librosPrestados;
    }
}


