package com.duoc.principal;

import com.duoc.controles.CalcularFacturacion;
import com.duoc.controles.ManejadorVehiculos;
import com.duoc.entidades.Vehiculo;
import com.duoc.entidades.VehiculoCarga;
import com.duoc.entidades.VehiculoPasajero;
import java.util.Scanner;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 14 julio 2024 
 * @asignatura:  POO I
 * @actividad: EFT S9
 *
 */
public class Main {

    public static void main(String[] args) {
        ManejadorVehiculos manejador = new ManejadorVehiculos();
        Scanner teclado = new Scanner(System.in);

        //Menu
        int opcion;
        do {
            menuPri();
            opcion = teclado.nextInt();
            teclado.nextLine(); //limpiar buffer
            switch (opcion) {
                case 1 -> agregarVehiculo(teclado, manejador);
                case 2 -> manejador.mostrarTodosLosVehiculos();
                case 3 -> calcularBoleta(teclado,manejador);
                case 4 -> {
                    System.out.println("Ingrese el nombre del archivo");
                }
                case 5 -> {
                }
                case 6 -> System.out.println("Saliendo del sistema.");
                default -> System.out.println("Ipcion no valida.");
            }
        } while (opcion != 8);

    }

    private static void agregarVehiculo(Scanner sc, ManejadorVehiculos manejador) {
        System.out.print("Patente: ");
        String patente = sc.nextLine();

        System.out.print("Marca: ");
        String marca = sc.nextLine();

        System.out.print("Modelo: ");
        String modelo = sc.nextLine();

        System.out.print("Anio: ");
        int anio = sc.nextInt();
        sc.nextLine();  //limpia buffer

        System.out.print("Ingrese el tipo de vehiculo (Pasajero/Carga): ");
        String tipo = sc.nextLine();

        if (tipo.equalsIgnoreCase("Pasajero")) {
            System.out.print("Ingrese la cantidad de pasajeros:");
            int cantidadPasajeros = sc.nextInt();
            sc.nextLine();  //limpiar buffer

            VehiculoPasajero vehiculoPasajero = new VehiculoPasajero(patente, marca, modelo, anio, cantidadPasajeros);
            manejador.agregarVehiculo(patente, vehiculoPasajero);
            System.out.println("Vehiculo de pasajeros agregado correctamente");
        } else if (tipo.equalsIgnoreCase("Carga")) {
            System.out.print("Ingrese la capacidad de carga en toneladas: ");
            double capacidadCarga = sc.nextDouble();
            sc.nextLine();  //limpiar buffer

            VehiculoCarga vehiculoCarga = new VehiculoCarga(patente, marca, modelo, anio, capacidadCarga);
            manejador.agregarVehiculo(patente, vehiculoCarga);
            System.out.println("Vehiculo de carga agregado correctamente.");
        } else {
            System.out.println("Tipo de Vehiculo no valido");
        }
    }

    //Menú Principal
    private static void menuPri() {
        String s;
        s = """
        -------------------------------------------
         |||||     Rent-a-Car BriefDrive     |||||
        -------------------------------------------
        |||  1--> Ingresar vehiculos.           ||| 
        |||  2--> Mostrar vehiculos.            ||| 
        |||  3--> Boleta vehiculos.             ||| 
        |||  4--> Listar Arriendo vehiculos.    ||| 
        |||  5--> Cargar desde archivo.         ||| 
        |||  6--> Grabar vehiculos en archivo.  ||| 
        |||  7--> Crear archivo CSV.            |||
        |||  8--> Salir.                        |||
        -------------------------------------------
        Seleccione su opcion:""";
        System.out.print(s);
    }

    private static void calcularBoleta(Scanner sc, ManejadorVehiculos manejador) {
        System.out.print("Ingrese patente del vehiculo: ");
        String clave = sc.nextLine();
        
        Vehiculo auto = manejador.obtenerVehiculo(clave);
        if (auto != null) {
            double precioConDescuento = 0.0;
            if (auto instanceof CalcularFacturacion) {
                CalcularFacturacion calcular = (CalcularFacturacion) auto;
                precioConDescuento = calcular.calcularPrecioConDescuento();
            }else{
                System.out.println("El vehiculo no valido");
                return;
            }
            System.out.println("Boleta para el vehiculo");
            auto.mostrarDetalles();
            System.out.println("Precio con descuento: $"+precioConDescuento);
        }
    }
}
