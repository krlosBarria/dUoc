package com.duoc.controles;

import com.duoc.entidades.Vehiculo;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 14 julio 2024 
 * @asignatura:  POO I
 * @actividad: EFT S9
 *
 */
public class ManejadorVehiculos {
    private Map<String, Vehiculo> vehiculos;
    
    public ManejadorVehiculos(){
        vehiculos = new HashMap<>();
    }
    
    public void agregarVehiculo(String clave, Vehiculo vehiculo){
        vehiculos.put(clave, vehiculo);
    }
    
    public Vehiculo obtenerVehiculo(String clave){
        return vehiculos.get(clave);
    }
    
    public void mostrarTodosLosVehiculos(){
        System.out.println("Listado de los vehiculos");
        for (Vehiculo objecto : vehiculos.values()) {
            objecto.mostrarDetalles();
        }
    }
}
