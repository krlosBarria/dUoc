package com.duoc.controles;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 14 julio 2024 
 * @asignatura:  POO I
 * @actividad: EFT S9
 *
 */

public interface CalcularFacturacion {
    double calcularPrecioConDescuento();
}