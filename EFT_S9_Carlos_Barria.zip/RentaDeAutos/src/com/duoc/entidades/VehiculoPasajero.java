package com.duoc.entidades;

import com.duoc.controles.CalcularFacturacion;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 14 julio 2024 
 * @asignatura:  POO I
 * @actividad: EFT S9
 *
 */
public class VehiculoPasajero extends Vehiculo implements CalcularFacturacion{
    private int cantidadPasajeros;

    public VehiculoPasajero(String patente, String marca, String modelo, int anioFabricacion, int cantidadPasajeros) {
        super(patente, marca, modelo, anioFabricacion);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Vehículo de Pasajeros: " + patente + " " + marca + " " + modelo + " - Año " + anioFabricacion
                + " - Pasajeros: " + cantidadPasajeros);
    }

    @Override
    public double calcularPrecioConDescuento(){
        //Aplicar descuento del 7%
        double precioSinDescuento = 1000.0; //precio base
        double descuento = precioSinDescuento *0.07;
        return precioSinDescuento - descuento;
    }
}
