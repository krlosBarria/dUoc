package com.duoc.entidades;

import com.duoc.controles.CalcularFacturacion;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 14 julio 2024 
 * @asignatura:  POO I
 * @actividad: EFT S9
 *
 */
public class VehiculoCarga extends Vehiculo implements CalcularFacturacion{
    private double capacidadCarga;

    public VehiculoCarga(String patente, String marca, String modelo, int anioFabricacion, double capacidadCarga) {
        super(patente, marca, modelo, anioFabricacion);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void mostrarDetalles() {
        System.out.println("Vehiculo de Carga: " + patente + " " + marca + " " + modelo + " - Año " + anioFabricacion 
                + " Capacidad Carga: " + capacidadCarga + " Toneladas");
    }
    
    @Override
    public double calcularPrecioConDescuento() {
        // Aplicar descuento del 3% para vehículos de carga
        double precioSinDescuento = 2000.0;
        double descuento = precioSinDescuento * 0.03;
        return precioSinDescuento - descuento;
    }
    
}
