package com.duoc.entidades;

/**
 *
 * @autor: Carlos Barría Valdevenito
 * @fecha: 14 julio 2024 
 * @asignatura:  POO I
 * @actividad: EFT S9
 *
 */
public abstract class Vehiculo {

    String patente;
    String marca;
    String modelo;
    int anioFabricacion;

    //Constructores
    public Vehiculo() {
    }

    public Vehiculo(String patente, String marca, String modelo, int anioFabricacion) {
        this.patente = patente;
        this.marca = marca;
        this.modelo = modelo;
        this.anioFabricacion = anioFabricacion;
    }

    //Getters/Setters
    public String getPatente() {
        return patente;
    }

    public void setPatente(String patente) {
        this.patente = patente;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public void setAnioFabricacion(int anioFabricacion) {
        this.anioFabricacion = anioFabricacion;
    }

    //Método mostrarDetalles
    public abstract void mostrarDetalles();
}
