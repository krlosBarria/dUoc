package com.duoc.principal;

/**
 *
 * @author Carlos Barría Valdevenito
 * @fecha: Aug 19, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa S2 - Grupo 11
 *
 */
public class ComponenteConcreto implements Component {
    public void operacion(){
        //Implementación del componente concreto
    }
}
