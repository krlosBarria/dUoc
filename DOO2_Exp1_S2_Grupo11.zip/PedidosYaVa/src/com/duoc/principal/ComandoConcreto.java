
package com.duoc.principal;

import com.duoc.entidades.Receiver;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 19, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa S2 - Grupo 11
 *
 */
public class ComandoConcreto implements Command{
    private Receiver receptor;
    
    public ComandoConcreto(Receiver receptor) {
        this.receptor = receptor;
    }
    
    public void ejecutar(){
        receptor.accion();
    }
            
}
