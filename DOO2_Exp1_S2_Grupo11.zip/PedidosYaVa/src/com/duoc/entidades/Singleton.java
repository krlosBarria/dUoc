package com.duoc.entidades;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 19, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa S2 - Grupo 11
 *
 */
public class Singleton {

    //Única instacia privada de la clase Singleton
    private static Singleton instace;

    //Constructor privado para evitar instancias indirectas
    private Singleton() {
    }

    //Método estático para obtener instancia única
    public synchronized static Singleton getSingleton() {
        if (instace == null) {
            if (instace == null) {
                instace = new Singleton();
            }
        }
        return instace;
    }
}
