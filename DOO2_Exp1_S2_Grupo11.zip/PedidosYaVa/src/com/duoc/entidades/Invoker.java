
package com.duoc.entidades;

import com.duoc.principal.Command;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 19, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa S2 - Grupo 11
 *
 */
public class Invoker {
    private List<Command> comandos = new ArrayList<>();
    
    public void agregarComando(Command comando) {
        comandos.add(comando);
    }
    
    public void ejecutarComandos(){
        for (Command comando : comandos) {
            comando.ejecutar();
        }
    }
}
