
package com.duoc.entidades;

import com.duoc.principal.Component;

/**
 *
 * @author: Carlos Barría Valdevenito
 * @fecha: Aug 19, 2024
 * @asignatura: Desarrollo Orientado A Objetos II
 * @actividad: Actividad Formativa S2 - Grupo 11
 * 
 */
public class DecoradorConcreto extends Decorator{
    public DecoradorConcreto(Component componente){
        super(componente);
    }
//
//    @Override
//    public void operacion() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }
    
    public void operacion() {
        super.componente();
        //Agreagar fucionalidad adicional al componente
    }

}
