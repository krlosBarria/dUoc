package com.duoc.running;

import com.duoc.banca.Cliente;
import com.duoc.banca.Cuenta;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Carlos Barría Valdevenito Grupo 01 Fecha: 27 Mayo 2024 Semana 2
 * Actividad Sumativa 
 * Ramo: Desarrollo POO I
 *
 */
public class Main {

    private static Scanner teclado = new Scanner(System.in);
    private static String rutCli, nombreCli, apPatCli, apeMatCli, domicilioCli, comunaCli;
    private static int numCtaCli, telefonoCli, ctaCteCli, opcion;
    private static double saldoCli;
    private static Cuenta cuentaActiva = null;
    private static int contadorCuenta = 1;

    private static ArrayList<Cliente> clientes = new ArrayList<>();
    private static ArrayList<Cuenta> cuentas = new ArrayList<>();

    public static void main(String[] args) {

        do {
            menuPri();
            //Validacion de opcion ingresada sea correcta
            try {
                opcion = teclado.nextInt();
            } catch (Exception e) {
                System.out.println("*** Opcion No valida ***");
                opcion = 0;
                teclado.next(); //Limpiamos el buffer del scanner
            }

            switch (opcion) {
                case 1 ->
                    crearCliente();
                case 2 ->
                    crearCuenta();
                case 3 ->
                    seleccionarCuenta();
                case 4 ->
                    System.out.println("Gracias por su visita, Adios.");
                default ->
                    System.out.println("Opcion fuera de rango.\n");
            }

        } while (opcion != 4);
        teclado.close();
    }

    static void menuPri() {
        String s = """
                  ------:Menu:------
                  1. Registrar Cliente
                  2. Crear Cuenta
                  3. Seleccionar Cuenta
                  4. Salir
                  Seleccione su opcion:
                   """;
        System.out.println(s);
    }
    
    static void menuCuenta() {
        String s = """
                  ------: Menu Cuenta :------
                  1. Deposito
                  2. Giro
                  3. Ver datos Cuenta
                  4. Volver al menu Principal
                  Seleccione su opcion:
                   """;
        System.out.println(s);
    }

    //Metodo Crear Cliente
    static void crearCliente() {

        System.out.println("Complete la informacion del Cliente");
        System.out.print("Rut: ");
        teclado.nextLine();
        rutCli = teclado.nextLine();

        System.out.print("Nombres: ");
        nombreCli = teclado.nextLine();

        System.out.print("Apellido Paterno: ");
        apPatCli = teclado.nextLine();

        System.out.print("Apellido Materno: ");
        apeMatCli = teclado.nextLine();

        System.out.print("Domicilio: ");
        domicilioCli = teclado.nextLine();

        System.out.print("Comuna: ");
        comunaCli = teclado.nextLine();

        while (true) {
            System.out.print("Telefono: ");
            String entrada = teclado.nextLine();

            try {
                telefonoCli = Integer.parseInt(entrada);
                break;  //sale del bucle si se pudo convertir correctamente
            } catch (Exception e) {
                System.out.println("Valor invalido");
            }
        }

        while (true) {
            System.out.println("Cuenta Corriente: ");
            String entrada = teclado.nextLine();
            try {
                ctaCteCli = Integer.parseInt(entrada);
                break;  //sale del bucle si se pudo convertir correctamente
            } catch (Exception e) {
                System.out.println("Valor invalido");
            }
        }

        clientes.add(new Cliente(rutCli, nombreCli,apPatCli, apeMatCli, domicilioCli, comunaCli, telefonoCli, ctaCteCli));
    }

    //Mètodo Crear Cuenta
    static void crearCuenta() {
        //Si no hay Clientes, no se puede crear cuenta
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes, debes crearlo.");
            return;
        }
        
        String nombre;
        Cliente cliente;
        
        do {
            System.out.println("--- Nombre de Cliente ----"); teclado.nextLine();
            for (Cliente c : clientes) {
                System.out.println(c.getNombre());
            }
            System.out.print("Digite el nombre del cliente:");
            nombre = teclado.nextLine();
            cliente = validarCliente(nombre);
            
        } while (cliente == null);
        
        cuentas.add(new Cuenta(contadorCuenta++, 0, cliente));
    }
    
    //Método Valida el nombre del cliente
    static Cliente validarCliente(String nombre) {
        for (Cliente c : clientes) {
            if (c.getNombre().equals(nombre)) {
                return c;
            }
        }
        return null;
    }
    
    //Método Seleccionar Cuenta a trabajar
    static void seleccionarCuenta() {
        //si no hay cuenta
        if (cuentas.isEmpty()) {
            System.out.println("No hay cuenta.");
            return;
        }
        
        //sleccionar una cuenta
        int numCuenta;
        do {
            System.out.println("---- Cuentas -----");
            for (Cuenta c : cuentas) {
                System.out.println(c.toString());
            }
            
            System.out.println("Selecciona un numero de cuenta");teclado.nextLine();
            numCuenta = Integer.parseInt(teclado.nextLine());
        } while (!validarCuenta(numCuenta));
        
        //mostrar menu de cuenta
        System.out.println("Cuenta Activa");
        seleccionarOpcionCuenta();
    }

    //Método Valida Cuenta
    static boolean validarCuenta(int numCuenta) {
        for (Cuenta c: cuentas) {
            if (c.getNumeroCuenta() == numCuenta) {
                cuentaActiva = c;
                return true;
            }
        }
        return false;
    }
    
    //Método menu secundario de Cuenta
    static void seleccionarOpcionCuenta() {
        int opcionCuenta = 0;
        while (opcionCuenta != 4) {
            menuCuenta();
            opcionCuenta = Integer.parseInt(teclado.nextLine());
            switch (opcionCuenta) {
                case 1 -> depositar();
                case 2 -> girar();
                case 3 -> cuentaActiva.verDatos();
                case 4 -> System.out.println("Volver al menu principal");
                default -> System.out.println("Opcion no valida");
            }
        }
    }
    
    static void depositar() {
        System.out.print("Ingrese cantidad a Depositar: $");
        int cantidad = Integer.parseInt(teclado.nextLine());
        cuentaActiva.ingreso(cantidad);
        System.out.println("Saldo Total: "+cuentaActiva.getSaldo());
    }

    static void girar() {
        System.out.print("Ingrese cantidad a girar: $");
        int cantidad = Integer.parseInt(teclado.nextLine());
        cuentaActiva.retiro(cantidad);
    }
}
